/**************************************************************************/
//                                                                        //
//   Author:    T.Warburton                                               //
//   Design:    T.Warburton && S.Sherwin                                  //
//   Date  :    12/4/96                                                   //
//                                                                        //
//   Copyright notice:  This code shall not be replicated or used without //
//                      the permission of the author.                     //
//                                                                        //
/**************************************************************************/

#include <math.h>
#include <veclib.h>
#include "hotel.h"

/* local declarations */
static void reshuffle(Element_List **,int);

static double  Alpha_CNAB[][3] = {
  {1., 0., 0.},
  {1., 0., 0.},
  {1., 0., 0.}};

static double  Beta_CNAB[][3] = {
  {1.0 ,       0.0    ,  0.0      },
  {3.0/2.0,   -1.0/2.0,  0.0      },
  {23.0/12.0, -4.0/3.0,  5.0/12.0 }};


static double  Beta_AM[][3] = {
  {1.0 ,       0.0    ,  0.0      },
  {1.0/2.0,    1.0/2.0,  0.0      },
  {5.0,        8.0,     -1.0      }};

double         Gamma_CNAB[3] = { 1., 1., 1.};

static double Alpha_Int[3] = { 1.0, 0.0, 0.0};
static double  Beta_Int[3] = { 1.0, 0.0, 0.0};
static double Gamma_Int    = 1.0;

void   getalpha(double *a){ dcopy(3,Alpha_Int,1,a,1); }
void   getbeta(double *b) { dcopy(3,Beta_Int,1,b,1); }
double getgamma(void)         { return Gamma_Int; }

void set_order_CNAB(int Je){ 
  dcopy(3, Alpha_CNAB[Je-1], 1, Alpha_Int, 1);
  dcopy(3,  Beta_CNAB[Je-1], 1,  Beta_Int, 1);
  Gamma_Int =  Gamma_CNAB[Je-1];
}

void set_order_CNAM(int Je){ 
  dcopy(3, Alpha_CNAB[Je-1], 1, Alpha_Int, 1);
  dcopy(3,  Beta_AM[Je-1], 1,  Beta_Int, 1);
}

/* This routine integrates the transformed values */
void integrate_CNAB(int Je, double dt, Element_List *U, Element_List *Uf[]){
  register  int i;
  int       nq = U->hjtot*U->nz;

  dsmul(nq, Beta_Int[Je-1]*dt, Uf[Je-1]->base_hj, 1, Uf[Je-1]->base_hj, 1);
  
  for(i = 0; i < Je-1; ++i)
    daxpy(nq, Beta_Int[i]*dt, Uf[i]->base_hj,1, Uf[Je-1]->base_hj, 1);
  
  dvadd(nq, Uf[Je-1]->base_hj,1, U->base_hj, 1, U->base_hj, 1);
  
  reshuffle(Uf,Je);
}
  
static void reshuffle(Element_List *U[],int N){
  int i; 
  Element_List *t = U[N-1];
  for(i = N-1; i; --i) U[i] = U[i-1];
  U[0] = t;
}

static void reshuffle(double **u,int N){
  int i;
  double *t = u[N-1];
  for(i = N-1; i; --i) u[i] = u[i-1];
  u[0] = t;
}

/* This routine integrates the physical values */
void Integrate_CNAB(int Je, double dt, Element_List *U, Element_List *Uf,
		    double **u, double **uf){
  register  int i;
  int       nq;
  double    theta = dparam("THETA");

  nq = U->htot*U->nz;
  dcopy(nq, Uf->base_h, 1, uf[0], 1);

  /* multiply u^n by theta factor */
  dscal(nq, 1.0/(1-theta),U->base_h,1); // ideally should put outside library
  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt,  uf[i], 1, U->base_h,1);
  
  reshuffle(uf,Je);
}

/* This routine integrates the physical values */
void integrate_CNAB(int Je, double dt, Element_List *U, Element_List *Uf,
		    double **u, double **uf){
  register  int i;
  int       nq;
  double    theta = dparam("THETA");

  nq = U->hjtot*U->nz;
  dcopy(nq, Uf->base_hj, 1, uf[0], 1);

  /* multiply u^n by theta factor */
  dscal(nq, 1.0/(1-theta),U->base_hj,1); // ideally should put outside library
  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt,  uf[i], 1, U->base_hj,1);
  
  reshuffle(uf,Je);
}

/* This routine integrates the physical values */
void Integrate_AB(int Je, double dt, Element_List *U, Element_List *Uf,
		    double **u, double **uf){
  register  int i;
  int       nq;


  nq = U->htot*U->nz;
  dcopy(nq, Uf->base_h, 1, uf[0], 1);

  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt,  uf[i], 1, U->base_h,1);
  
  reshuffle(uf,Je);
}

/* This routine integrates the physical values */
void Integrate_AM(int Je, double dt, Element_List *U, Element_List *Uf,
		    double **u, double **uf){
  register  int i;
  int       nq;
  double    theta = dparam("THETA");

  nq = U->htot*U->nz;
  dcopy(nq, Uf->base_h, 1, uf[0], 1);

  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt,  uf[i], 1, U->base_h,1);
  
  reshuffle(uf,Je);
}

/* This routine integrates the physical values */
void Integrate_CNAM(int Je, double dt, Element_List *U, Element_List *Uf,
		    double **u, double **uf){
  register  int i;
  int       nq;
  double    theta = dparam("THETA");

  nq = U->htot*U->nz;
  dcopy(nq, Uf->base_h, 1, uf[0], 1);

  /* multiply u^n by theta factor */
  dscal(nq, 1.0/(1-theta),U->base_h,1);
  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt,  uf[i], 1, U->base_h,1);
  
  reshuffle(uf,Je);
}

static double Alpha_SS[][3] = {
  { 1.0,      0.0,     0.0},
  { 2.0, -1.0/2.0,     0.0},
  { 3.0, -3.0/2.0, 1.0/3.0}};
#if 0
static double  Beta_SS[][3] = {
  { 1.0,  0.0, 0.0},
  { 2.0, -1.0, 0.0},
  { 3.0, -3.0, 1.0}};
#else
static double  Beta_SS[][3] = {
  { 1.0,  0.0, 0.0},
  { 2.0, -1.0, 0.0},
  { 5.0/2.0, -2.0, 1.0/2.0}};
#endif

double Gamma_SS[3] = { 1., 3./2., 11./6.};

double getgamma(int i){ return Gamma_SS[i-1];}

static int tmp_order = 1;

void set_order(int Je){ 
  tmp_order = Je;
  dcopy(3, Alpha_SS[Je-1], 1, Alpha_Int, 1);
  dcopy(3,  Beta_SS[Je-1], 1,  Beta_Int, 1);
  Gamma_Int =  Gamma_SS[Je-1];
}

/* This routine integrates the physical values with a stiffly stable scheme */
void Integrate_SS(int Je, double dt, Element_List *U, Element_List *Uf, 
		                     double **u,      double **uf){
  register  int i;
  int       nq;

  nq = U->htot*U->nz;
  dcopy(nq,  U->base_h, 1,  u[0], 1);
  dcopy(nq, Uf->base_h, 1, uf[0], 1);

  dsmul(nq, Alpha_Int[Je-1], u[Je-1], 1,U->base_h, 1);
  
  for(i = 0; i < Je-1; ++i)
    daxpy(nq, Alpha_Int[i],    u[i], 1, U->base_h, 1);
  
  for(i = 0; i < Je; ++i)
    daxpy(nq, Beta_Int[i]*dt, uf[i], 1, U->base_h, 1);

  reshuffle( u, Je);
  reshuffle(uf, Je);
}

void Integrate_SS(int Je, double dt, Element_List *U, Element_List *Uf,
                                     double **u,      double **uf, int bnoiterate)
{ 
  register  int i;
  int       nq;
  double    inv2p = dparam("DBCRELAX"); ///(it/4.+1.);
 
  nq = U->htot*U->nz;
 
  if( bnoiterate )
  { 
    reshuffle( u, Je);
    reshuffle(uf, Je);
 
    dcopy(nq,  U->base_h, 1,  u[0], 1);
    dcopy(nq, Uf->base_h, 1, uf[0], 1);
  }
 
  dsmul(nq, Alpha_Int[Je-1], u[Je-1], 1,U->base_h, 1);
 
  for(i = 0; i < Je-1; ++i)
    daxpy(nq, Alpha_Int[i],    u[i], 1, U->base_h, 1);


#if 1

  if(bnoiterate)
  { 
    for(i = 0; i < Je; ++i)
      daxpy(nq, Beta_Int[i]*dt, uf[i], 1, U->base_h, 1);
  } 
  else 
  { 
      daxpy(nq, (1.-inv2p)*dt, Uf->base_h, 1, U->base_h, 1);
     for(i = 0; i < Je; ++i)
      daxpy(nq, inv2p*Beta_Int[i]*dt, uf[i], 1, U->base_h, 1);

//      daxpy(nq, 0.5*dt, uf[1], 1, U->base_h, 1);
  }
#else

      daxpy(nq, dt, Uf->base_h, 1, U->base_h, 1);
 
#endif
} 





void Integrate_SUBITER(int Je, Element_List *U, double **u, double *result){

  //copy solution field from U to temorary u,
  //integrate result[i] = sum_{k=0}^{k<Je} (alpha_k*u[k][i])
  //do not reshuffle

  double alpha0, alpha1, alpha2, val;
  double *u0,*u1,*u2, *dptr_h;
  int i,htot;

  htot = U->htot*U->nz;

  switch (Je){

  case 2:
    alpha0 = Alpha_Int[0];
    alpha1 = Alpha_Int[1];
    dptr_h = U->base_h;
    u0=u[0];
    u1=u[1];
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val+alpha1*u1[i];
    }
    break;

  case 1:
    alpha0 = Alpha_Int[0];
    u0 = u[0];
    dptr_h = U->base_h;
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val;
    }

    break;

  case 3:
    u0 = u[0];
    u1=u[1];
    u2 = u[2];
    dptr_h = U->base_h;
    alpha0 = Alpha_Int[0];
    alpha1 = Alpha_Int[1];
    alpha2 = Alpha_Int[2];
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val+alpha1*u1[i]+alpha2*u2[i];
    }
    break;
  default:
    fprintf(stderr,"time_integration with Je = %d are not supported, using Je=1\n",Je);
    exit(-1);
  }
  reshuffle( u, Je);
}



void Integrate_SUBITER(int Je, int Jnl, Element_List *U, double **u, double **uf, double *result){

  //copy solution field from U to temorary u,
  //integrate result[i] = sum_{k=0}^{k<Je} (alpha_k*u[k][i])
  //reshuffle "u"
  //add non-linear terms from time levels n, n-1,... at the end
  //do not reshuffle "uf"

  double alpha0, alpha1, alpha2, val, dt;
  double *u0,*u1,*u2, *dptr_h;
  int i,htot;

  htot = U->htot*U->nz;

  switch (Je){

  case 2:
    alpha0 = Alpha_Int[0];
    alpha1 = Alpha_Int[1]; 
    dptr_h = U->base_h;
    u0=u[0];
    u1=u[1];
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val+alpha1*u1[i];
    }
    
    break;
  case 1:
    alpha0 = Alpha_Int[0];
    u0 = u[0];
    dptr_h = U->base_h;
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val;
    }

    break;
  case 3:
    u0 = u[0];
    u1=u[1];
    u2 = u[2];
    dptr_h = U->base_h;
    alpha0 = Alpha_Int[0];
    alpha1 = Alpha_Int[1];
    alpha2 = Alpha_Int[2];
    for (i = 0; i < htot; ++i){
      val = dptr_h[i];
      u0[i] = val;
      result[i] = alpha0*val+alpha1*u1[i]+alpha2*u2[i];
    }
    break;
  default:
    fprintf(stderr,"time_integration with Je = %d are not supported, using Je=1\n",Je);
    exit(-1);
  }
  reshuffle( u, Je);
  
  
  //add non-linear term using Adams Moulton integration coefficients
  //here we add non-linear term from time level n, n-1, ...
  dt = dparam("DT");
  switch (Jnl){

  case 1:
    ;
    break;
  case 2:
    alpha0 = -dt*Beta_AM[1][1]; 
    dptr_h = U->base_h;
    u0=uf[1];
    for (i = 0; i < htot; ++i){
      result[i] += alpha0*u0[i];
    }
    
    break;
  case 3:
    u0 = uf[1];
    u1 = uf[2];
    alpha0 = -dt*Beta_AM[2][1];
    alpha1 = -dt*Beta_AM[2][2];
    for (i = 0; i < htot; ++i){
      result[i] += alpha0*u0[i]+alpha1*u1[i];
    }
    break;
  default:
    fprintf(stderr,"time_integration with Je = %d are not supported, using Je=1\n",Je);
    exit(-1);
  }
  
  //reshuffle uf only after outer iterations converged and nl^{n+1} is available
}

