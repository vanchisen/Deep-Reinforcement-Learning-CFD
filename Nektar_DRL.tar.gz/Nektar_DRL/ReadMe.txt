
#compiling  on Linux

1)  cd rfftw/
    make
    cp *.a ../Hlib/Linux/

2) cd Veclib/
     ./compile
     cp *.a ../Hlb/Linux/

3) cd Hlib/Linux/
      ./compile

4) cd Fourier/Linux/
     ./compile
