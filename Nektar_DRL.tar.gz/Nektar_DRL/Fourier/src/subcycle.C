#include <stdio.h>
#include <math.h>
#include <veclib.h>
#include <hotel.h>
#include <time.h>
#include "nektarF.h"
#include <rfftw.h>

extern rfftw_plan rplan, rplan_inv;
extern rfftw_plan rplan32, rplan_inv32;

#define EulerStep(htot,Un,Uf,U,dt) \
 dsvtvp(htot,dt,Uf,1,Un,1,U,1); 

static void Upwind_edge_advection(Element_List *U, Element_List *V, Element_List *W, 
				  Element_List *UF, Element_List *VF, Element_List *WF);
static void Add_surface_contrib(Element_List *Us, Element_List *Uf);
static void Fill_edges(Element_List *U, Element_List *Uf, Bndry *Ubc,double t);
static void Project   (Element_List *U, Element_List *Uf, double *wk);
static void SubtractBC(Element_List *in, Element_List *out, Bndry *Bc, double dt);
static void ExtField(int htot, double t, double *un, double **up, double dt, 
		     int ord);
static void ExtForce(int NZ, double t, double *f_int, double *f_n, double *olf_f, double dt, 
		   int ord);

// RK arrays
static double BarrayC[2][2]    = {{1,0},{0.5,1}};
static double BarrayA[2][2][2] = {{{1,0},{0,0}},{{0.5,0},{-1,2}}};
static double BarrayB[2][3]    = {{0.5,0.5,0},{1/6.0,2/3.0,1.0/6.0}};

static void AverageVel(int N, double  **Uf,double *Barray, double  *Uout, 
		       int ntot);

#define TIMING

#ifdef TIMING
#define AddTime(s) \
 s += (clock()-st)/cps; \
 st = clock();
#else
#define AddTime(s) \
 /* Nothing */
#endif

static void Advance (int N, double dt, double *u, double *v, double *w, Domain *Omega,
		     int Je);

static double st, ts[7], cps = (double)CLOCKS_PER_SEC;

static void reshuffle(double **u,int N){
  int i;
  double *t = u[N-1];
  for(i = N-1; i; --i) u[i] = u[i-1];
  u[0] = t;
}

void SubCycle(Domain *Omega, int Order){
  register int i,j,k,N;
  double   dt  = Omega->dt;
  double   cfl;
  Element_List *U,*V,*W,*Uf,*Vf,*Wf;
  int      Je = iparam("INTYPE");
  double   time = dparam("t");
  double   alpha[3],**velstore;
  int      MinSteps = iparam("MinSteps");

  static Nek_Trans_Type f_to_p = F_to_P,
                        p_to_f = P_to_F;

  U   = Omega->U;
  V   = Omega->V;
  W   = Omega->W;
  Uf  = Omega->Uf;
  Vf  = Omega->Vf;
  Wf  = Omega->Wf;

  int htot = U->nz*U->htot;

  st = clock();
  dzero(7,ts,1);

  cfl = cfl_checker(Omega,dt);
  AddTime(ts[0]);  
  N = (int) (cfl/0.6) + 1;
  N = max(N,MinSteps);
  dt /= (double)N;

  fprintf(stdout,"N: %d, cfl = %lf\n",(int) N, cfl/N);
  velstore = dmatrix(0,1,0,htot-1);
  
  // put  u^n into lagrangian vel ul
  dcopy(htot,Omega->u[0],1,Omega->ul[0],1);
  dcopy(htot,Omega->v[0],1,Omega->vl[0],1);
  dcopy(htot,Omega->w[0],1,Omega->wl[0],1);
  
  // advance Omega->u, Oemga->v by N*dt 
  // this is main part of subcycing 
  for(i = 0; i < Order; ++i)
    Advance(N,dt,Omega->ul[i],Omega->vl[i],Omega->wl[i], Omega,Order);
  
#ifdef TIMING
  ROOT {
  fprintf(stderr,"\t cfl_checker... Took %lf second\n",ts[0]);
  fprintf(stderr,"\t Convective.... Took %lf second\n",ts[1]);
  fprintf(stderr,"\t Fill edges.... Took %lf second\n",ts[2]);
  fprintf(stderr,"\t Upwinding..... Took %lf second\n",ts[3]);
  fprintf(stderr,"\t Add Surf Cont. Took %lf second\n",ts[4]);
  fprintf(stderr,"\t Projection.... Took %lf second\n",ts[5]);
  fprintf(stderr,"\t Avg./Euler.... Took %lf second\n",ts[6]);
 }
#endif

  // calculate explicit part of backwards approximation of
  //  Du/Dt *dt and store in [Je-1] for viscous solve
  getalpha(alpha);
  dsmul(htot, alpha[Order-1], Omega->ul[Order-1], 1, Omega->ul[Order-1], 1);
  for(i = 0; i < Order-1; ++i)
    daxpy(htot, alpha[i], Omega->ul[i], 1, Omega->ul[Order-1], 1);

  dsmul(htot, alpha[Order-1], Omega->vl[Order-1], 1, Omega->vl[Order-1], 1);
  for(i = 0; i < Order-1; ++i)
    daxpy(htot, alpha[i], Omega->vl[i], 1, Omega->vl[Order-1], 1);

  dsmul(htot, alpha[Order-1], Omega->wl[Order-1], 1, Omega->wl[Order-1], 1);
  for(i = 0; i < Order-1; ++i)
    daxpy(htot, alpha[i], Omega->wl[i], 1, Omega->wl[Order-1], 1);

  dcopy(htot,Omega->ul[Order-1],1,U->base_h,1);
  dcopy(htot,Omega->vl[Order-1],1,V->base_h,1);
  dcopy(htot,Omega->wl[Order-1],1,W->base_h,1);

  //go to (P,Q)-space
  U->Trans(U, f_to_p);
  V->Trans(V, f_to_p);
  W->Trans(W, f_to_p);
  // store full derivative approx of Du/Dt in Uf for pressure BC's  
  for(k = 0; k < U->nz; ++k) {
   Fill_edges (U->flevels[k],U->flevels[k], Omega->Ubc[k],time+N*dt);
   SubtractBC (U->flevels[k],Uf->flevels[k],Omega->Ubc[k],Omega->dt);
   Fill_edges (V->flevels[k],V->flevels[k], Omega->Vbc[k],time+N*dt);
   SubtractBC (V->flevels[k],Vf->flevels[k],Omega->Vbc[k],Omega->dt);
   Fill_edges (W->flevels[k],W->flevels[k], Omega->Wbc[k],time+N*dt);
   SubtractBC (W->flevels[k],Wf->flevels[k],Omega->Wbc[k],Omega->dt);
  }

  //Uf,Vf,Wf go to (F,Q)-space
  Uf->Trans(Uf, p_to_f);
  Vf->Trans(Vf, p_to_f);
  Wf->Trans(Wf, p_to_f);
  // copy in n into u
  dcopy(htot,Omega->u[0],1,U->base_h,1);
  dcopy(htot,Omega->u[0],1,V->base_h,1);
  dcopy(htot,Omega->w[0],1,W->base_h,1);
  
  SetPBCs(Omega);

  dcopy(htot,Omega->ul[Order-1],1,U->base_h,1);
  dcopy(htot,Omega->vl[Order-1],1,V->base_h,1);
  dcopy(htot,Omega->wl[Order-1],1,W->base_h,1);

  reshuffle(Omega->ul,Je);
  reshuffle(Omega->vl,Je);
  reshuffle(Omega->wl,Je);

  reshuffle(Omega->u,Je+1);
  reshuffle(Omega->v,Je+1);
  reshuffle(Omega->w,Je+1);

}

#if 0 // RK version 
static void Advance (int N, double dt, double *u, double *v, Domain *Omega,
		     int Je){
  register int i,j,k;
  Element_List *U,*V,*W, *Uf,*Vf, *Wf;
  double time = dparam("t");
  int htot = U->nz*U->htot;
  
  U  = Omega->U;
  V  = Omega->V;
  W  = Omega->W;
  Uf = Omega->Uf;
  Vf = Omega->Vf;
  Wf = Omega->Wf;
  
  for(i = 0; i < N; ++i){
    dcopy(htot,u,1,U->base_h,1);
    dcopy(htot,v,1,V->base_h,1);
    dcopy(htot,w,1,W->base_h,1);
    
    SkewSymmetricAdv (Omega); 

    AddTime(ts[1]);
    
    // DG convection
   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+i*dt);
    Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+i*dt);
    Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+i*dt);
   }
    AddTime(ts[2]);
    
    Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
    AddTime(ts[3]);
    
    // put upwinded flux minus local flux (stored in U) into Uf 
   for(k = 0; k < U->nz; ++k) {
    Add_surface_contrib   (U->flevels[k],Uf->flevels[k]);
    Add_surface_contrib   (V->flevels[k],Vf->flevels[k]);
    Add_surface_contrib   (W->flevels[k],Wf->flevels[k]);
   }
    AddTime(ts[4]);
    
   for(k = 0; k < U->nz; ++k) {
    InnerProduct_Orth     (Uf->flevels[k],Uf->flevels[k]);
    InnerProduct_Orth     (Vf->flebels[k],Vf->flevels[k]);  
    InnerProduct_Orth     (Wf->flebels[k],Wf->flevels[k]);  
    
    Jtransbwd_Orth        (Uf->flevels[k],Uf->flevels[k]);
    Jtransbwd_Orth        (Vf->flevels[k],Vf->flevels[k]);
    Jtransbwd_Orth        (Wf->flevels[k],Wf->flevels[k]);
   }

    AddTime(ts[5]);

    if(Je-1){
      // store previous flux
      dcopy(htot,Uf->base_h,1,Omega->uf[0],1);
      dcopy(htot,Vf->base_h,1,Omega->vf[0],1);
      dcopy(htot,Wf->base_h,1,Omega->wf[0],1);

      // calculate average velocity
      AverageVel (Je-1,Omega->uf,BarrayA[Je-2][0],Uf->base_h,htot);
      AverageVel (Je-1,Omega->vf,BarrayA[Je-2][0],Vf->base_h,htot);
      AverageVel (Je-1,Omega->wf,BarrayA[Je-2][0],Wf->base_h,htot);

      EulerStep  (htot,u,Uf->base_h,U->base_h,dt);
      EulerStep  (htot,v,Vf->base_h,V->base_h,dt);
      EulerStep  (htot,w,Wf->base_h,W->base_h,dt);
      AddTime(ts[6]);
      
      // new flux evaluation
      SkewSymmetricAdv (Omega); 
//#ifdef SPM
//    ExtForce(U->htot, i*dt, Uf->base_h, Omega->ut[0], Omega->ut[1], Omega->dt, 2);
//    ExtForce(V->htot, i*dt, Vf->base_h, Omega->vt[0], Omega->vt[1], Omega->dt, 2);
//#endif
      AddTime(ts[1]);
    
      // DG convection
    for(k = 0; k < U->nz; ++k) {
      Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+(i+BarrayC[Je-2][0])*dt);
      Fill_edges            (V->flevels[k],V->flebels[k],Omega->Vbc[k],time+(i+BarrayC[Je-2][0])*dt);
      Fill_edges            (W->flevels[k],W->flebels[k],Omega->Wbc[k],time+(i+BarrayC[Je-2][0])*dt);
     }
      AddTime(ts[2]);
      
      Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
      AddTime(ts[3]);
     
    for(k = 0; k < U->nz; ++k) {
      Add_surface_contrib   (U->flevels[k],Uf->flevels[k]);
      Add_surface_contrib   (V->flevels[k],Vf->flevels[k]);
      Add_surface_contrib   (W->flevels[k],Wf->flevels[k]);
     }
      AddTime(ts[4]);

    for(k = 0; k < U->nz; ++k) {
      InnerProduct_Orth     (Uf->flevels[k],Uf->flevels[k]);
      InnerProduct_Orth     (Vf->flevels[k],Vf->flevels[k]);  
      InnerProduct_Orth     (Wf->flevels[k],Wf->flevels[k]);  
      
      Jtransbwd_Orth        (Uf->flevels[k],Uf->flevels[k]);
      Jtransbwd_Orth        (Vf->flevels[k],Vf->flevels[k]);
      Jtransbwd_Orth        (Wf->flevels[k],Wf->flevels[k]);
     }

      AddTime(ts[5]);

      // store previous flux
      dcopy(htot,Uf->base_h,1,Omega->uf[1],1);
      dcopy(htot,Vf->base_h,1,Omega->vf[1],1);
      dcopy(htot,Wf->base_h,1,Omega->wf[1],1);

//      AverageVel (Je,Omega->uf,BarrayB[Je-2],Uf->base_h,Uf->nel);
//      AverageVel (Je,Omega->vf,BarrayB[Je-2],Vf->base_h,Vf->nel);
//      AverageVel (Je,Omega->wf,BarrayB[Je-2],Wf->base_h,Wf->nel);
      AverageVel (Je,Omega->uf,BarrayB[Je-2],Uf->base_h,htot);
      AverageVel (Je,Omega->vf,BarrayB[Je-2],Vf->base_h,htot);
      AverageVel (Je,Omega->wf,BarrayB[Je-2],Wf->base_h,htot);
    }
    
    EulerStep  (htot,u,Uf->base_h,u,dt);
    EulerStep  (htot,v,Vf->base_h,v,dt);
    EulerStep  (htot,w,Wf->base_h,w,dt);
    AddTime(ts[6]);
  }
}
#else // AB version
static void Advance (int N, double dt, double *u, double *v, double *w, Domain *Omega,
		     int Je){
  register int i,j,k;
  Element_List *U,*V,*W,*Uf,*Vf,*Wf;
  double time = dparam("t");
  double Beta[3],*uf,*vf,*wf;
  int Iord = Je;
  
  static Nek_Trans_Type f_to_p = F_to_P,
                        p_to_f = P_to_F;

  if (option("dealias"))
   {
     fprintf(stderr,"-deal option doesn't work for IntOpSplit solver...\n");
     exit(-1);
   }

  U  = Omega->U;
  V  = Omega->V;
  W  = Omega->W;
  Uf = Omega->Uf;
  Vf = Omega->Vf;
  Wf = Omega->Wf;
  
  uf = Omega->uf[0];
  vf = Omega->vf[0];
  wf = Omega->wf[0];
  
  int htot = U->nz*U->htot;
#if 1
  //Do first substep using RK  
  dcopy(htot,u,1,U->base_h,1);
  dcopy(htot,v,1,V->base_h,1);
  dcopy(htot,w,1,W->base_h,1);
   
  //go to (P,Q)-space
  U->Trans(U, f_to_p);
  V->Trans(V, f_to_p);
  W->Trans(W, f_to_p);

#ifdef Extrapolate
  // DG convection
  // fill edges with u
  for(k = 0; k < U->nz; ++k) {
   Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+i*dt);
   Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+i*dt);
   Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+i*dt);
  }
  
  // interpolate 
  ExtField(htot,0,Uf->base_h,Omega->u,Omega->dt,min(Omega->step,Je));
  ExtField(htot,0,Vf->base_h,Omega->v,Omega->dt,min(Omega->step,Je));
  ExtField(htot,0,Wf->base_h,Omega->w,Omega->dt,min(Omega->step,Je));

  Uf->Set_state('p');
  Vf->Set_state('p');
  Wf->Set_state('p');

  //go to (P,Q)-space
  Uf->Trans(Uf, f_to_p);
  Vf->Trans(Vf, f_to_p);
  Wf->Trans(Wf, f_to_p);
  
  for(k = 0; k < U->nz; ++k) {
  Fill_edges            (Uf->flevels[k],Uf->flevels[k],Omega->Ubc[k],time);
  Fill_edges            (Vf->flevels[k],Vf->flevels[k],Omega->Vbc[k],time);
  Fill_edges            (Wf->flevels[k],Wf->flevels[k],Omega->Wbc[k],time);
  }

  AddTime(ts[2]);
  
  Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
  AddTime(ts[3]);
#else
  // DG convection
  //Fill_edges            (U,U,Omega->Ubc,time);
  //Fill_edges            (V,V,Omega->Vbc,time);
  for(k = 0; k < U->nz; ++k) {
   Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+i*dt);
   Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+i*dt);
   Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+i*dt);
  }
  AddTime(ts[2]);
  
  Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
  AddTime(ts[3]);
#endif
  
  SkewSymmetricAdv (Omega); 
  AddTime(ts[1]);
  
  // put upwinded flux minus local flux (stored in U) into Uf 
  for(k = 0; k < U->nz; ++k) {
   Add_surface_contrib   (U->flevels[k],Uf->flevels[k]);
   Add_surface_contrib   (V->flevels[k],Vf->flevels[k]);
   Add_surface_contrib   (W->flevels[k],Wf->flevels[k]);
  }

  AddTime(ts[4]);
  
  for(i=10; i<20; i++)
  fprintf(stderr,"U: %lf Uf: %lf \n",U->base_h[i], Uf->base_h[i]);

  for(k = 0; k < U->nz; ++k) {
   InnerProduct_Orth     (Uf->flevels[k],Uf->flevels[k]);
   InnerProduct_Orth     (Vf->flevels[k],Vf->flevels[k]);  
   InnerProduct_Orth     (Wf->flevels[k],Wf->flevels[k]); 
   Jtransbwd_Orth        (Uf->flevels[k],Uf->flevels[k]);
   Jtransbwd_Orth        (Vf->flevels[k],Vf->flevels[k]);
   Jtransbwd_Orth        (Wf->flevels[k],Wf->flevels[k]);
  }
  
  
  AddTime(ts[5]);
  
  if(Je-1){
    // store previous flux
    dcopy(htot,Uf->base_h,1,Omega->uf[0],1);
    dcopy(htot,Vf->base_h,1,Omega->vf[0],1);
    dcopy(htot,Wf->base_h,1,Omega->wf[0],1);
    
    // calculate average velocity
    AverageVel (Je-1,Omega->uf,BarrayA[Je-2][0],Uf->base_h,htot);
    AverageVel (Je-1,Omega->vf,BarrayA[Je-2][0],Vf->base_h,htot);
    AverageVel (Je-1,Omega->wf,BarrayA[Je-2][0],Wf->base_h,htot);
    
    EulerStep  (htot,u,Uf->base_h,U->base_h,dt);
    EulerStep  (htot,v,Vf->base_h,V->base_h,dt);
    EulerStep  (htot,w,Wf->base_h,W->base_h,dt);

    AddTime(ts[6]);
    
  //go to (P,Q)-space
    U->Trans(U, f_to_p);
    V->Trans(V, f_to_p);
    W->Trans(W, f_to_p);

#ifdef Extrapolate
    // DG convection
    // fill edges with u
   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+BarrayC[Je-2][0]*dt);
   }

    // interpolate 
    ExtField(htot,BarrayC[Je-2][0]*dt,Uf->base_h,
	     Omega->u,Omega->dt,min(Omega->step,Je));
    ExtField(htot,BarrayC[Je-2][0]*dt,Vf->base_h,
	     Omega->v,Omega->dt,min(Omega->step,Je));
    ExtField(htot,BarrayC[Je-2][0]*dt,Wf->base_h,
	     Omega->w,Omega->dt,min(Omega->step,Je));

    Uf->Set_state('p');
    Vf->Set_state('p');
    Wf->Set_state('p');
    
    //go to (P,Q)-space
    Uf->Trans(Uf, f_to_p);
    Vf->Trans(Vf, f_to_p);
    Wf->Trans(Wf, f_to_p);

   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (Uf->flevels[k],Uf->flevels[k],Omega->Ubc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (Vf->flevels[k],Vf->flevels[k],Omega->Vbc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (Wf->flevels[k],Wf->flevels[k],Omega->Wbc[k],time+BarrayC[Je-2][0]*dt);
    }

    AddTime(ts[2]);
    
    Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
    AddTime(ts[3]);
#else
    // DG convection
   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+BarrayC[Je-2][0]*dt);
    Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+BarrayC[Je-2][0]*dt);
   }
    AddTime(ts[2]);
    
    Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
    AddTime(ts[3]);
#endif

    // new flux evaluation
    SkewSymmetricAdv (Omega); 
    AddTime(ts[1]);
    
   for(k = 0; k < U->nz; ++k) {
    Add_surface_contrib   (U->flevels[k],Uf->flevels[k]);
    Add_surface_contrib   (V->flevels[k],Vf->flevels[k]);
    Add_surface_contrib   (W->flevels[k],Wf->flevels[k]);
   }

    AddTime(ts[4]);
    
    //go to (F,Q)-space
   for(k = 0; k < U->nz; ++k) {
    InnerProduct_Orth     (Uf->flevels[k],Uf->flevels[k]);
    InnerProduct_Orth     (Vf->flevels[k],Vf->flevels[k]);  
    InnerProduct_Orth     (Wf->flevels[k],Wf->flevels[k]);  
    
    Jtransbwd_Orth        (Uf->flevels[k],Uf->flevels[k]);
    Jtransbwd_Orth        (Vf->flevels[k],Vf->flevels[k]);
    Jtransbwd_Orth        (Wf->flevels[k],Wf->flevels[k]);
   }
    
    AddTime(ts[5]);
    
    // store previous flux
    dcopy(htot,Uf->base_h,1,Omega->uf[1],1);
    dcopy(htot,Vf->base_h,1,Omega->vf[1],1);
    dcopy(htot,Wf->base_h,1,Omega->wf[1],1);
    
//    AverageVel (Je,Omega->uf,BarrayB[Je-2],Uf->base_h,Uf->nel);
//    AverageVel (Je,Omega->vf,BarrayB[Je-2],Vf->base_h,Vf->nel);
//    AverageVel (Je,Omega->vf,BarrayB[Je-2],Wf->base_h,Wf->nel);
    AverageVel (Je,Omega->uf,BarrayB[Je-2],Uf->base_h,htot);
    AverageVel (Je,Omega->vf,BarrayB[Je-2],Vf->base_h,htot);
    AverageVel (Je,Omega->wf,BarrayB[Je-2],Wf->base_h,htot);
  }
  
  EulerStep  (htot,u,Uf->base_h,u,dt);
  EulerStep  (htot,v,Vf->base_h,v,dt);
  EulerStep  (htot,w,Wf->base_h,w,dt);

  AddTime(ts[6]);

  // finish off using AB - max of order 2 at present
  if(Iord == 3) fprintf(stderr,"Warning 3rd order is not debugged\n");

  set_order_CNAB(Iord);
  getbeta(Beta);
  for(i = 1; i < N; ++i){
#else
  for(i = 0; i < N; ++i){

    if(i)
      set_order_CNAB(Iord);
    else
      set_order_CNAB(1);
    
    getbeta(Beta);
#endif
    dcopy(htot,u,1,U->base_h,1);
    dcopy(htot,v,1,V->base_h,1);
    dcopy(htot,w,1,W->base_h,1);
    
    //go to (P,Q)-space
     U->Trans(U, f_to_p);
     V->Trans(V, f_to_p);
     W->Trans(W, f_to_p);
#ifdef Extrapolate
    // DG convection
    // fill edges with u
   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+i*dt);
    Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+i*dt);
    Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+i*dt);
   }

    // interpolate 
    ExtField(htot,i*dt,Uf->base_h,Omega->u,Omega->dt,min(Omega->step,Je));
    ExtField(htot,i*dt,Vf->base_h,Omega->v,Omega->dt,min(Omega->step,Je));
    ExtField(htot,i*dt,Wf->base_h,Omega->w,Omega->dt,min(Omega->step,Je));
    Uf->Set_state('p');
    Vf->Set_state('p');
    Wf->Set_state('p');
    
    //go to (P,Q)-space
     Uf->Trans(Uf, f_to_p);
     Vf->Trans(Vf, f_to_p);
     Wf->Trans(Wf, f_to_p);

   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (Uf->flevels[k],Uf->flevels[k],Omega->Ubc[k],time+i*dt);
    Fill_edges            (Vf->flevels[k],Vf->flevels[k],Omega->Vbc[k],time+i*dt);
    Fill_edges            (Wf->flevels[k],Wf->flevels[k],Omega->Wbc[k],time+i*dt);
   }

    AddTime(ts[2]);
    
    Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
    AddTime(ts[3]);
#else
    // DG convection
   for(k = 0; k < U->nz; ++k) {
    Fill_edges            (U->flevels[k],U->flevels[k],Omega->Ubc[k],time+i*dt);
    Fill_edges            (V->flevels[k],V->flevels[k],Omega->Vbc[k],time+i*dt);
    Fill_edges            (W->flevels[k],W->flevels[k],Omega->Wbc[k],time+i*dt);
   }

    AddTime(ts[2]);
    
    Upwind_edge_advection (U,V,W,Uf,Vf,Wf);
    AddTime(ts[3]);
#endif

    // calcualte forcing within element 
    SkewSymmetricAdv (Omega); 
    AddTime(ts[1]);
    
    // put upwinded flux minus local flux (stored in U) into Uf 
   for(k = 0; k < U->nz; ++k) {
    Add_surface_contrib   (U->flevels[k],Uf->flevels[k]);
    Add_surface_contrib   (V->flevels[k],Vf->flevels[k]);
    Add_surface_contrib   (W->flevels[k],Wf->flevels[k]);
   }
    AddTime(ts[4]);
    
   for(k = 0; k < U->nz; ++k) {
    InnerProduct_Orth     (Uf->flevels[k],Uf->flevels[k]);
    InnerProduct_Orth     (Vf->flevels[k],Vf->flevels[k]);  
    InnerProduct_Orth     (Wf->flevels[k],Wf->flevels[k]);  
    
    Jtransbwd_Orth        (Uf->flevels[k],Uf->flevels[k]);
    Jtransbwd_Orth        (Vf->flevels[k],Vf->flevels[k]);
    Jtransbwd_Orth        (Wf->flevels[k],Wf->flevels[k]);
   }

    AddTime(ts[5]);
    
    // integrate using Adams Bashforth
    daxpy(htot,dt*Beta[0],Uf->base_h,1,u,1);
    daxpy(htot,dt*Beta[0],Vf->base_h,1,v,1);
    daxpy(htot,dt*Beta[0],Wf->base_h,1,w,1);
    
    if(Iord-1){ // 2nd order terms
      daxpy(htot,dt*Beta[1],uf,1,u,1);
      daxpy(htot,dt*Beta[1],vf,1,v,1);
      daxpy(htot,dt*Beta[1],wf,1,w,1);
      
      dcopy(htot,Uf->base_h,1,uf,1);
      dcopy(htot,Vf->base_h,1,vf,1);
      dcopy(htot,Wf->base_h,1,wf,1);
    }
    AddTime(ts[6]);
  }

  set_order(Je);
}
#endif
// needs to be process into Element_list structure 
static void SubtractBC(Element_List *in, Element_List *out, Bndry *Bc, double dt){
  int    eid, qedg, qa, qb;
  double *f, *fi, *u, *uf,**im;
  Bndry  *B;
  Edge   *e;
  double gamma;

  gamma = getgamma();

  fi = dvector(0,QGmax-1);
  
  /* set up boundary conditions  */
  for(B = Bc; B; B = B->next){
    if((B->type == 'V')||(B->type == 'W')){
      eid  = B->elmt->id;
      e    = in->flist[eid]->edge[B->face].link;
      qedg = e->qedg;
      f    = e->h;
      u    = in ->flist[eid]->h[0];
      uf   = out->flist[eid]->h[0];
      qa   = in->flist[eid]->qa;
      qb   = in->flist[eid]->qb;
      
      switch(B->face){
      case 0:
	getim (qedg,qa,&im,g2a);
  	Interp(*im,f,qedg,fi,qa);
	dscal (qa,gamma,fi,1);
	dvsub (qa,u,1,fi,1,uf,1);
	dscal (qa,1/dt,uf,1);
	break;
      case 1:
	getim (qedg,qb,&im,g2b);
  	Interp(*im,f,qedg,fi,qb);
	dscal (qb,gamma,fi,1);
	dvsub (qb,u+qa-1,qa,fi,1,uf+qa-1,qa);
	dscal (qb,1/dt,uf+qa-1,qa);
	break;
      case 2:
	if(in->flist[eid]->identify() == Nek_Quad){
	  getim (qedg,qa,&im,g2a);
	  Interp(*im,f,qedg,fi,qa);
	  dscal (qa,gamma,fi,1);
	  dvsub (qa,u+qa*(qb-1),1,fi,1,uf+qa*(qb-1),1);
	  dscal (qa,1/dt,uf+qa*(qb-1),1);
	}
	else{
	  getim (qedg,qb,&im,g2b);
	  Interp(*im,f,qedg,fi,qb);
	  dscal (qb,gamma,fi,1);
	  dvsub (qb,u,qa,fi,1,uf,qa);
	  dscal (qb,1/dt,uf,qa);
	}
	break;
      case 3:
	getim (qedg,qb,&im,g2b);
  	Interp(*im,f,qedg,fi,qb);
	dscal (qb,gamma,fi,1);
	dvsub (qb,u,qa,fi,1,uf,qa);
	dscal (qb,1/dt,uf,qa);
	break;
      }
    }
  }
  free(fi);
}


/* Sum Uout = sum_N Uf[i]*Barray[i]                                   */
/* Note: Summation is in reverse order due to second call in SubCycle */
static void AverageVel(int N, double  **Uf, double *Barray, 
		       double  *Uout, int ntot){
  int i,k,l;
  
  dsmul(ntot,Barray[N-1],Uf[N-1],1,Uout,1);
    
  for(i = N-2; i >=0; --i)
    daxpy(ntot,Barray[i],Uf[i],1,Uout,1);
}

/* ------------------------------------------------------------------*
 * This function fills the edges array 'edge->h' with the physical
 * values of the state vector. It also fills the edge->link->h array
 * of any boundary value with the appropriate boundary conditions. All
 * values are interpolated to the gauss points of order edge->qedg.
 * This assumes that the state vector Us is in physical space.
 *
 * W - the same as reflexive but with no characteristic b.c. 
 * 
 * S - outflow b.c., is updated every time step 
 * ----------------------------------------------------------------- */

static  void update_bndry_h(Bndry *Bc);
static void Fill_edges(Element_List *U, Element_List *Uf, Bndry *Ubc, double t){
  Element      *E,*Ef;
  Bndry        *B;
  Edge         *e;
  int          eid;
  int          tvary = option("tvarying");

  if(U->fhead->state != 'p')
    error_msg(Fill_edges: state vector not in physical space);
  
  /* set interior edge points */
  for(E=U->fhead,Ef = Uf->fhead;E;E=E->next,Ef=Ef->next)
    Ef->fill_edges(E->h[0], NULL, NULL);
  
  /* set up boundary conditions  */
  for(B = Ubc; B; B = B->next){
    if(tvary)
      update_bndry_h(B);
    
    eid = B->elmt->id;
    e    = Uf->flist[eid]->edge[B->face].link;
    dcopy(e->qedg,B->phys_val_g,1,e->h,1);
  }
  
//#ifdef PARALLEL
//  DO_PARALLEL  exchange_edges(U);  
//#endif  
}


// should probably be put in library 
static  void update_bndry_h(Bndry *Bc){
  int     qt,qedg;
  double  *f,**im;
  Coord   X;
  Element *E = Bc->elmt;
  
  qedg = E->edge[Bc->face].qedg;

  if(E->identify() == Nek_Tri){
    if(Bc->face == 0){
      qt = E->qa;
      getim(qt,qedg,&im,a2g); 
    }
    else {
      qt = E->qb;
      getim(qt,qedg,&im,b2g); 
    }
  }
  else{
    if((Bc->face == 0)||(Bc->face == 2)){
      qt = E->qa;
      getim(qt,qedg,&im,a2g); 
    }
    else {
      qt = E->qb;
      getim(qt,qedg,&im,b2g); 
    }
  }    

  X.x = dvector(0,qt-1);
  X.y = dvector(0,qt-1);
  f   = dvector(0,qt-1);

  vector_def("x y",Bc->bstring);

  E->GetFaceCoord(Bc->face,&X);
  vector_set(qt,X.x,X.y,f);
  
  /* store gaussian distribution for euler part */
  Interp(*im,f,qt,Bc->phys_val_g,qedg);

  free(X.x);  free(X.y);  free(f);
    
  return;
}

static void Add_surface_contrib(Element_List *Us, Element_List *Uf){
  Element *E, *Ef;
  
  for(E = Us->fhead, Ef = Uf->fhead; E; E = E->next, Ef = Ef->next)
    E->Add_Surface_Contrib(Ef, *Ef->h, 'n');
} 

/* calculate upwinded normal flux normal and put in Uf. The interior
   flux is also put in U */
static void Upwind_edge_advection(Element_List *U,  Element_List *V, Element_List *W, 
				  Element_List *UF, Element_List *VF, Element_List *WF){
  register     int i,j;
  int          *loc_id,*adj_id,qedg;
  Coord        *normal;
  double       sloc,sadj,floc,fadj;
  double       un, un_loc, un_adj;  
  static int   *forward,*reverse;
  Element      *Us, *Vs, *Ws, *Uf, *Vf, *Wf;
  static Nek_Trans_Type f_to_p = F_to_P,
                        p_to_f = P_to_F;

  if(!reverse){
    forward = ivector(0,QGmax-1);
    for(i = 0; i < QGmax; ++i) forward[i] = i;
    reverse = ivector(0,QGmax-1);
    for(i = 0; i < QGmax; ++i) reverse[i] = QGmax-1-i;
  }
  
  /* only need to calculate the edges which have edge->link defined */
  for(Us = U->fhead, Vs = V->fhead, Ws = W->fhead, Uf = UF->fhead, Vf = VF->fhead, Wf = WF->fhead; Us;
      Us = Us->next, Vs = Vs->next, Ws = Ws->next, Uf = Uf->next, Vf = Vf->next, Wf = Wf->next){
    
    for(i = 0; i < Us->Nedges; ++i)
      if(Us->edge[i].link){
	normal = Us->edge[i].norm; 
	qedg   = Us->edge[i].qedg;

	if(Us->edge[i].con)
	  loc_id = reverse + QGmax-qedg; /* reverse ordering */
	else
	  loc_id = forward;
	
	if(Us->edge[i].link->con)
	  adj_id = reverse + QGmax-qedg; /* reverse ordering */
	else
	  adj_id = forward;	    
	
	/* finally put upwinded flux calculation in here */
	for(j = 0; j < qedg; ++j){
	  
#ifdef Extrapolate
	  // calcualte normal velcoity based on avaerage of both sides 
	  un_loc = Uf->edge[i].h[loc_id[j]]*normal->x[loc_id[j]] + 
	    Vf->edge[i].h[loc_id[j]]*normal->y[loc_id[j]];
	  
	  un_adj = Uf->edge[i].link->h[adj_id[j]]*normal->x[loc_id[j]] + 
	    Vf->edge[i].link->h[adj_id[j]]*normal->y[loc_id[j]];
#else
	  // calcualte normal velcoity based on avaerage of both sides 
	  un_loc = Us->edge[i].h[loc_id[j]]*normal->x[loc_id[j]] + 
	    Vs->edge[i].h[loc_id[j]]*normal->y[loc_id[j]];
	  
	  un_adj = Us->edge[i].link->h[adj_id[j]]*normal->x[loc_id[j]] + 
	    Vs->edge[i].link->h[adj_id[j]]*normal->y[loc_id[j]];
#endif
	  
	  un = 0.5*(un_loc + un_adj);
	  
	  /* calculate upwinded flux for Uf */
	  if(un < 0){
	    floc =  un_adj*Us->edge[i].link->h[adj_id[j]]; 
	    fadj = -floc;
	  }
	  else{      
	    floc =  un_loc*Us->edge[i].h[loc_id[j]]; 
	    fadj = -floc;
	  }

	  Uf->edge[i].h[loc_id[j]]       = floc;
	  Uf->edge[i].link->h[adj_id[j]] = fadj;

	  /* calculate upwinded flux for Vf*/
	  if(un < 0){
	    floc =  un_adj*Vs->edge[i].link->h[adj_id[j]]; 
	    fadj = -floc;
	  }
	  else{      
	    floc =  un_loc*Vs->edge[i].h[loc_id[j]]; 
	    fadj = -floc;
	  }

	  Vf->edge[i].h[loc_id[j]]       = floc;
	  Vf->edge[i].link->h[adj_id[j]] = fadj;

	  /* calculate upwinded flux for Wf*/
	  if(un < 0){
	    floc =  un_adj*Ws->edge[i].link->h[adj_id[j]]; 
	    fadj = -floc;
	  }
	  else{      
	    floc =  un_loc*Ws->edge[i].h[loc_id[j]]; 
	    fadj = -floc;
	  }

	  Wf->edge[i].h[loc_id[j]]       = floc;
	  Wf->edge[i].link->h[adj_id[j]] = fadj;

	  /* store local flux in Us fields */
	  Us->edge[i].h[loc_id[j]]        *=  un_loc;
	  Us->edge[i].link->h[adj_id[j]]  *= -un_adj;

	  /* store local flux in Vs fields */
	  Vs->edge[i].h[loc_id[j]]        *=  un_loc;
	  Vs->edge[i].link->h[adj_id[j]]  *= -un_adj;

	  /* store local flux in Ws fields */
	  Ws->edge[i].h[loc_id[j]]        *=  un_loc;
	  Ws->edge[i].link->h[adj_id[j]]  *= -un_adj;
	}

	// negate fluxes to make the consistent with a RHS terms
	dneg(qedg,Us->edge[i].h,1);
	dneg(qedg,Vs->edge[i].h,1);
	dneg(qedg,Ws->edge[i].h,1);
	dneg(qedg,Uf->edge[i].h,1);
	dneg(qedg,Vf->edge[i].h,1);
	dneg(qedg,Wf->edge[i].h,1);
	dneg(qedg,Us->edge[i].link->h,1);
	dneg(qedg,Vs->edge[i].link->h,1);
	dneg(qedg,Ws->edge[i].link->h,1);
	dneg(qedg,Uf->edge[i].link->h,1);
	dneg(qedg,Vf->edge[i].link->h,1);
	dneg(qedg,Wf->edge[i].link->h,1);

      }
  }

  TransformEdges(U, p_to_f);
  TransformEdges(V, p_to_f);
  TransformEdges(W, p_to_f);
  TransformEdges(UF, p_to_f);
  TransformEdges(VF, p_to_f);
  TransformEdges(WF, p_to_f);
}

/* Function to project orthogonal bases by setting up matrix and 
   multiplying all element storage. Assumes fixed order and clustering
   of types */
static int SetupProjection(double **P, Element *U);

static void Project(Element_List *U, Element_List *Uf, double *wk){
  static int init = 1, Ptot;
  static double *P; 
  int nel = U->nel;
  
  if(init){
    Ptot = SetupProjection(&P, U->fhead);
    init = 0;
  }
  
  dgemm('n','n',Ptot,nel,Ptot,1.0,P,Ptot,U->base_h,Ptot,0.0,wk, Ptot);
  dcopy(U->htot,wk,1,Uf->base_h,1);
}

static int SetupProjection(double **P, Element *U){
  int i;
  int L = U->dgL;
  int qtot = U->qtot;
  double *p;
  
  P[0] =  dvector(0,qtot*qtot-1); 
  dzero(qtot*qtot,*P,1);

  for(i = 0; i < qtot; ++i){
    p = P[0] + i*qtot;
    p[i] = 1;
    U->Ofwd(p,p,L);
    U->Obwd(p,p,L);
  }

  return qtot;
}

/* extrapolate field using equally time spaced field un,un-1,un-2, (at
   dt intervals) to time n+t at order Ord */
static void ExtField(int htot, double t, double *un, double **up, double dt, 
		   int ord){
  register int i,j;
  double l[4];
		
  // calculate lagrange interpolants
  dfill(4,1,l,1);
  for(i = 0; i <= ord; ++i)
    for(j = 0; j <= ord; ++j)
      if(i != j){
	l[i] *= (j*dt+t);
	l[i] /= (j*dt-i*dt);
      }

  dsmul(htot,l[0],up[0],1,un,1);
  for(i = 1; i <= ord; ++i)
    daxpy(htot,l[i],up[i],1,un,1);
  
  return;
}

