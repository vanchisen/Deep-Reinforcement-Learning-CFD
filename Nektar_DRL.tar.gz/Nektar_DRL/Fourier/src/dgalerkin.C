#include <stdio.h>
#include <math.h>
#include <veclib.h>
#include <hotel.h>
#include <string.h>
#include "nektarF.h"
  
/* 
   This function declares the edge stucture edge->h. The size of the
   edge is set at present to the minimum of the two order either side
   of the element. They also correspond to Gauss points which are set
   at an order of L as given by edge->qedg. Boundary edge which have a
   edge->base == NULL are set up to have a dummy edge connected to
   edge->link for the physical values of the boundary conditions */

void set_elmt_edges(Element_List *E){
  register int i,j,k,c;
  Edge    *e;
  int     edgtot;
  double  tot,*wa,*wb,*wk,w;
  Element *U;
  
  wk = dvector(0,QGmax-1);
  
  for(k = 0; k < E->nel; ++k)   /* set up number of quadrature points */
    for(i = 0,e=E->flist[k]->edge; i < E->flist[k]->Nedges; ++i){
      e[i].qedg = E->flist[e[i].eid]->dgL;
    }
  
  for(k = 0; k < E->nel; ++k){   
    getzw(E->flist[k]->qa,&wa,&wa,'a');
    
    if(E->flist[k]->identify() == Nek_Tri)
      getzw(E->flist[k]->qb,&wb,&wb,'b'); 
    else
      getzw(E->flist[k]->qb,&wb,&wb,'a'); 
    
    for(i = 0, e=E->flist[k]->edge; i < E->flist[k]->Nedges; ++i){
      /* set up weights for based on edge area for viscous terms */
      if(E->flist[k]->curvX){
	for(j = 0; j < E->flist[k]->qb; ++j)
	  wk[j] = ddot(E->flist[k]->qa,wa,1,
		       E->flist[k]->geom->jac.p+j*E->flist[k]->qa,1);
	e[i].weight = ddot(E->flist[k]->qb,wb,1,wk,1);
      }
      else{
	e[i].weight = E->flist[k]->geom->jac.d;
      }
      
      /* loop through and set qedg to maximum and allocate e[i].h */
      if(e[i].base){
	/* see if there is an adjacent edge */
	if(e[i].link)
	  e[i].qedg = max(e[i].qedg,e[i].link->qedg);
	else
	  e[i].qedg = max(e[i].qedg,e[i].base->qedg);
	e[i].h = dvector(0,e[i].qedg-1);
      }
      else{ // set up dummy edges
	e[i].link = (Edge *)calloc(1,sizeof(Edge));
	memcpy(e[i].link,e+i,sizeof(Edge));
	e[i].link->base = e+i;
	e[i].h       = dvector(0,e[i].qedg-1);
	e[i].link->h = dvector(0,e[i].qedg-1);
      }
    }
  }

#if 0
#ifdef PARALLEL
  if( set_elmt_edges_init ){ 
    DO_PARALLEL{  /* if parallel sort out connecting elements info */
    
      int      **ibuf,nb;
      int      ncprocs = pllinfo.ncprocs,min;
      double   **dbuf;
      ConInfo  *cinfo = pllinfo.cinfo;
      
      
      /* set up buffers */
      for(i = 0, nb=0; i < ncprocs; ++i)
	nb = max(nb,cinfo[i].nedges);
      
            
      ibuf = imatrix(0,ncprocs-1,0,nb-1);
      

      /* Fill buffer with connectivity and swap */
      for(i = 0; i < ncprocs; ++i){
	for(j = 0; j < cinfo[i].nedges; ++j)
	  ibuf[i][j] = E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].con;
	
	SendRecvRep(ibuf[i],sizeof(int)*(cinfo[i].nedges),cinfo[i].cprocid);
      }
      
      /* unpack information */
      for(i = 0; i < ncprocs; ++i)
	for(j = 0; j < cinfo[i].nedges; ++j)
	  E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].link->con = ibuf[i][j];
      /* Fill buffer with qedg and swap */
      for(i = 0; i < ncprocs; ++i){
	for(j = 0; j < cinfo[i].nedges; ++j)
	  ibuf[i][j] = E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].qedg;
	
	SendRecvRep(ibuf[i],sizeof(int)*(cinfo[i].nedges),cinfo[i].cprocid);
      }
      
      /* unpack information and set qedg to maximum  */
      for(i = 0; i < ncprocs; ++i)
	for(j = 0; j < cinfo[i].nedges; ++j){
	  e = E->flist[cinfo[i].elmtid[j]]->edge + cinfo[i].edgeid[j];
	  e->link->qedg = ibuf[i][j];
	  if(e->qedg != e->link->qedg){
	    e->qedg = e->link->qedg = max(e->qedg,e->link->qedg);
	    free(e->h); e->h = dvector(0,e->qedg-1);
	    free(e->link->h); e->link->h = dvector(0,e->link->qedg-1);
	  }
	}
      free_imatrix(ibuf,0,0);
      
      
      dbuf = dmatrix(0,ncprocs-1,0,nb-1);
 
      /* Fill buffer with weight and swap */
      for(i = 0; i < ncprocs; ++i){
	for(j = 0; j < cinfo[i].nedges; ++j)
	  dbuf[i][j] = E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].weight;
	
	SendRecvRep(dbuf[i],sizeof(double)*(cinfo[i].nedges),cinfo[i].cprocid);
      }
      
      /* unpack information */
      for(i = 0; i < ncprocs; ++i)
	for(j = 0; j < cinfo[i].nedges; ++j)
	  E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].link->weight
	    = dbuf[i][j];
      
      free_dmatrix(dbuf,0,0);
      
      /* finally count up length of all edge contributions */
      for(i = 0; i < ncprocs; ++i){
	cinfo[i].datlen = 0;
	for(j = 0; j < cinfo[i].nedges; ++j)
	  cinfo[i].datlen += E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].qedg;
      }
      
      /* set base  of connecting element edge to point to itself  */
      /* in order to set weights up correctly and then reverse settings */
      /* to avoid confusion in gen_aux_field routine                    */
      for(i = 0; i < ncprocs; ++i){
	for(j = 0; j < cinfo[i].nedges; ++j)
	  E->flist[cinfo[i].elmtid[j]]->edge[cinfo[i].edgeid[j]].base =
	    E->flist[cinfo[i].elmtid[j]]->edge + cinfo[i].edgeid[j];
      } 
    }
  }
#endif
#endif

  
  /* loop through edges and calculate edge weights as ratio of the local
     area of adjacent elements - otherwise set it to be 1 */
  for(U=E->fhead;U;U = U->next){
    for(i = 0; i < U->Nedges; ++i)
      if(U->edge[i].base){
	if(U->edge[i].link){
	  tot = U->edge[i].weight + U->edge[i].link->weight;
	  
	  w = U->edge[i].weight/tot;
	  U->edge[i].weight =  U->edge[i].link->weight/tot;
	  U->edge[i].link->weight = w;
	}
      }
      else{
	U->edge[i].weight = 1;
	U->edge[i].link->weight = 0;
      }
  }
#ifdef PARALLEL
  DO_PARALLEL{
    for(i = 0; i < pllinfo.ncprocs; ++i){
      for(j = 0; j < pllinfo.cinfo[i].nedges; ++j)
	E->flist[pllinfo.cinfo[i].elmtid[j]]->edge[pllinfo.cinfo[i].edgeid[j]].base =
	  (Edge *) NULL;
    }
  }
#endif
  
  free(wk);
}



/* set up outward facing normals along faces as well as the edge
   jacobeans divided by the jacobean for the triangle. All points
   are evaluated at the  gauss quadrature points */

void set_edge_geofac(Element_List *EL){
  Element *E;
  
  for(E=EL->fhead;E;E = E->next)
    E->set_edge_geofac();
}



void Jtransbwd_Orth(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;
  for(U=EL->fhead,Uf = ELf->fhead;U;U = U->next,Uf = Uf->next)
    Uf->Obwd(U->h[0], Uf->h[0], Uf->dgL);
}



void EJtransbwd_Orth(Element *U, double *in, double *out){
  U->Obwd(in, out, U->dgL);
}



void InnerProduct_Orth(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;
  for(U=EL->fhead,Uf = ELf->fhead;U;U = U->next,Uf = Uf->next)
    Uf->Ofwd(U->h[0], Uf->h[0], Uf->dgL);
}


void EInnerProduct_Orth(Element *U, double *in, double *out){
  U->Ofwd(in, out, U->dgL);
}






