/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source:
 * $Revision:
 * $Date: 
 * $Author: 
 * $State: 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include "nektarF.h"

/* local functions */
Bsystem *gen_bsystem(Element_List *E, Bndry *Ebc);

static void set_bmap       (Element *, Bsystem *);
static int  suminterior    (Element *E);
static void BasicNumScheme (Element_List *E, Bndry *Ebc, Bsystem *Bsys);
int bandwidth(Element *E, Bsystem *Bsys);
#if 0
Bsystem *gen_bsystem(Element_List *UL, Bndry *Ebc){
  Bsystem  *Bsys;
  Element  *E = UL->fhead;
  Bsys       = (Bsystem *)calloc(1,sizeof(Bsystem));
  Bsys->Gmat = (MatSys  *)malloc(   sizeof(MatSys));
  
  if(option("iterative")) Bsys->smeth = iterative;
  
  /* basis numbering scheme for vertices, edges and faces */
  BasicNumScheme(UL,Ebc,Bsys);
  
  if(E->dim() == 2){
    option_set("recursive",10);
    Recursive_SC_decom(E,Bsys);
  }
  else{
    Bsys->smeth = direct;
    bandwidthopt(E,Bsys);
    fprintf(stderr,"rcm bandwidth (%c)   : %d [%d (%d)] \n",E->type,
	    bandwidth(E,Bsys),Bsys->nsolve,suminterior(E));
    fflush(stderr);
  }


#if 0
       else if(Bsys->smeth == direct){
    bandwidthopt(E,Bsys);
#if 0
    fprintf(stderr,"rcm bandwidth (%c)   : %d [%d (%d)] \n",E->type,
	     bandwidth(E,Bsys),Bsys->nsolve,suminterior(E));
    fflush(stderr);
#endif
  }
#endif

  /* set up boundary maps for element edges */
  set_bmap(E,Bsys);
  Bsys->families = iparam("FAMILIES");

  return Bsys;
}

#endif

Bsystem *gen_bsystem(Element_List *UL, Bndry *Ebc){
  Bsystem  *Bsys;
  Element  *E=UL->fhead;

  Bsys       = (Bsystem *)calloc(1,sizeof(Bsystem));

  if(option("iterative")) Bsys->smeth = iterative;

  /* basis numbering scheme for vertices, edges and faces */
  BasicNumScheme(UL,Ebc,Bsys);

  if(option("recursive"))
    Mlevel_SC_decom(UL,Bsys);
  else  if(Bsys->smeth == direct){
    bandwidthopt(E,Bsys);
    ROOT
      fprintf(stdout,"rcm bandwidth (%c)   : %d [%d (%d)] \n",E->type,
	      bandwidth(E,Bsys),Bsys->nsolve,suminterior(E));
    fflush(stdout);
  }
  
  /* set up boundary maps for element edges */
  set_bmap(E,Bsys);
  Bsys->families = iparam("FAMILIES");
  return Bsys;
}


static void  setGid(Element_List *E);

static void BasicNumScheme(Element_List *UL, Bndry *Ebc, Bsystem *Bsys){
  Element  *U = UL->fhead;
  register int i;
  int       nvg,nvs,neg,nes,nfg,nfs,scnt,ncnt;
  int      *gsolve,*gbmap,l,l1;
  Bndry    *Ubc; 
  Vert     *v;
  Edge     *e;
  Face     *f;

  Element *E;

  nfg = 0; /* compiler trick */

  setGid (UL);  /* setup a global numbering scheme i.e. without boundaries*/

  /* This part of the routine re-orders the vertices, edges and then
     the faces so that the knowns are listed first. For the edges and
     the faces it also initialises a cummalative list stored in Bsys. */
  
  /*--------------------*/
  /* Vertex re-ordering */
  /*--------------------*/

  /* find maximum number of global vertices; */
  for(E=U,nvg=0; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      nvg = (E->vert[i].gid > nvg)? E->vert[i].gid:nvg;
  ++nvg;
  

  gsolve = ivector(0,nvg-1);
  gbmap  = ivector(0,nvg-1);

  ifill(nvg, 1, gsolve,1);
  /* Assemble vertex solve mask to sort out multiplicity */
  for(E=U; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      gsolve[E->vert[i].gid] &= E->vert[i].solve;
  
  /* copy back mask */
  for(E=U; E; E = E->next){
    v = E->vert;
    for(i = 0; i < E->Nverts; ++i)
     v[i].solve = gsolve[E->vert[i].gid];
  }
  
  scnt = 0;  ncnt = 0;
  for(i = 0; i < nvg; ++i)
     gbmap[i] = gsolve[i]? scnt++:ncnt++;
  nvs = scnt;

  /* place unknowns at the end of the pile */
  for(i = 0; i < nvg; i++) 
    gbmap[i] += gsolve[i]?  0:nvs;

  /* replace vertices numbering into vertex structures */
  for(E=U; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      E->vert[i].gid = gbmap[E->vert[i].gid];

  free(gsolve); free(gbmap);

  /*------------------*/
  /* Edge re-ordering */
  /*------------------*/

  /* find maximum number of global edges; */
  for(E = U,neg=0; E; E = E->next)
    for(i = 0; i < E->Nedges; ++i)
      neg = (E->edge[i].gid > neg)? E->edge[i].gid:neg;
  ++neg;

  gsolve = ivector(0,neg-1);
  gbmap  = ivector(0,neg-1);

  /* form edge gsolve and gbmap */
  ifill(neg, 1, gsolve,1);
  for(Ubc = Ebc; Ubc; Ubc = Ubc->next)
    if((Ubc->type == 'V')||(Ubc->type == 'W')||(Ubc->type == 'o')){
      E = Ubc->elmt;
      l = Ubc->face;
      if(E->dim() == 2)
	gsolve[E->edge[l].gid] = 0;
      else 
	for(i = 0; i < E->Nfverts(l); ++i)
	  gsolve[E->edge[E->ednum(l,i)].gid] = 0;
    }
  
  scnt = 0;  ncnt = 0;
  for(i = 0; i < neg; ++i)
    gbmap[i] = gsolve[i]? (scnt++):(ncnt++);
  nes   = scnt;

  /* place unknowns at the end of the pile */
  for(i = 0; i < neg; ++i)
    gbmap[i] += gsolve[i]?  0:nes;

  /* replace sort gid's */
  for(E = U; E; E = E->next){
    e = E->edge;
    for(i = 0; i < E->Nedges; ++i)
      e[i].gid = gbmap[E->edge[i].gid];
  }
  
  /* set up cumulative edge list */
  Bsys->edge = ivector(0,neg);
  for(E = U; E; E = E->next)
    for(i = 0; i < E->Nedges; ++i)
      Bsys->edge[E->edge[i].gid] = E->edge[i].l;
  
  l = Bsys->edge[0];
  Bsys->edge[0] = 0;
  for(i = 1; i < neg; ++i){
    l1 = Bsys->edge[i];
    Bsys->edge[i] =  Bsys->edge[i-1]+l;
    l = l1;
  }
  Bsys->edge[i] =  Bsys->edge[i-1]+l;

  free(gsolve); free(gbmap);

  if(U->dim() == 3){
    /*------------------*/
    /* Face re-ordering */
    /*------------------*/
    
    /* find maximum number of global faces; */
    //  for(k = 0,nfg =0; k < nel; ++k)  
    for(E = U, nfg = 0; E; E = E->next)
      for(i = 0; i < E->Nfaces; ++i)
	nfg = (E->face[i].gid > nfg)? E->face[i].gid:nfg;
    ++nfg;
    
    gsolve = ivector(0,nfg-1);
    gbmap  = ivector(0,nfg-1);
    
    /* form faces part of gsolve, gbmap */
    ifill(nfg, 1, gsolve,1);
    for(Ubc = Ebc; Ubc; Ubc = Ubc->next)
      if((Ubc->type == 'V')||(Ubc->type == 'W')||(Ubc->type == 'o'))
	gsolve[Ubc->elmt->face[Ubc->face].gid] = 0;
    
    scnt = 0; ncnt = 0;
    for(i = 0; i < nfg; ++i)
      gbmap[i] = gsolve[i]? (scnt++):(ncnt++);
    nfs = scnt;
    
    /* place unknowns at the end of the pile */
    for(i = 0; i < nfg; ++i)
      gbmap[i] += gsolve[i]?  0:nfs;
    
    /* replace sorted gid's */
    for(E=U;E;E=E->next){
      f=E->face;
      for(i = 0; i < E->Nfaces; ++i)
	f[i].gid = gbmap[f[i].gid];
    }
    
    /* set up cumulative face list */
    Bsys->face = ivector(0,nfg);

    for(E=U;E;E=E->next){
      f = E->face;
      for(i = 0; i < E->Nfaces; ++i){
	Bsys->face[f[i].gid] = (E->Nfverts(i) == 3) ? f[i].l*(f[i].l+1)/2:
	  f[i].l*f[i].l;
      }
    }
    
    l = Bsys->face[0];
    Bsys->face[0] = 0;
    for(i = 1; i < nfg; ++i){
      l1 = Bsys->face[i];

      Bsys->face[i] =  Bsys->face[i-1] + l;
      l = l1;
    }
    Bsys->face[i] = Bsys->face[i-1] + l;
    
    free(gsolve); free(gbmap);
  }
  
  Bsys->nv_solve  = nvs;
  Bsys->ne_solve  = nes;
  Bsys->nel       = countelements(U);
  Bsys->nsolve    = nvs + Bsys->edge[nes];
  Bsys->nglobal   = nvg + Bsys->edge[neg];

  if(U->dim() == 3){
    Bsys->nsolve   += Bsys->face[nfs];
    Bsys->nglobal  += Bsys->face[nfg];
    Bsys->nf_solve  = nfs;
  }

  /* make numbering scheme consequative the unknowns are listed by
     vertices, edges and then faces */

  /* place known degree of freedom at end of list */
  for(E = U; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      if(E->vert[i].gid >= nvs)
	E->vert[i].gid += Bsys->nsolve-nvs;
  
  if(U->dim() == 3){
    for(i = 0; i < nfs; ++i)
      Bsys->face[i] += nvs + Bsys->edge[nes];
    
    ncnt = Bsys->nsolve + (nvg-nvs) +
      (Bsys->edge[neg]-Bsys->edge[nes]) - Bsys->face[nfs];
    for(i = nfs; i <= nfg; ++i)
      Bsys->face[i] += ncnt;
  }
  
  for(i = 0; i < nes; ++i)
    Bsys->edge[i] += nvs;
  
  ncnt = Bsys->nsolve + nvg-nvs - Bsys->edge[nes];
  for(i = nes; i <= neg; ++i)
    Bsys->edge[i] += ncnt;

}

typedef struct vertnum {
  int    id; 
  int   eid;
  int   vid;
  struct vertnum *base;
  struct vertnum *link;
} Vertnum;


static void setGid(Element_List *UL){
  Element  *U = UL->fhead;
  register int i,j,k;
  int      nvg, face, eid, edgeid, faceid, vertmax;
  const    int nel = UL->nel;
  Edge     *e,*ed;
  Face     *f;
  Vertnum  *V,*vb,*v,*vc;

  Element *E;

  /* set vector of consequative numbers */
  /* set up vertex list */
  vertmax = Max_Nverts;

  V = (Vertnum *) calloc(vertmax*nel,sizeof(Vertnum));
  for(k=0;k<nel;++k)
    for(i=0;i<vertmax;++i){
      V[k*vertmax+i].eid = k;
      V[k*vertmax+i].vid = i;
    }

  if(U->dim() == 2){
    for(E = U; E; E = E->next)
      for(i = 0; i < E->Nedges; ++i){
	for(j = 0; j < E->dim(); ++j){

	  v = V+E->id*vertmax + E->fnum(i,j);

	  if(E->edge[i].base){
	    if(E->edge[i].link){
	      eid  = E->edge[i].link->eid;
	      face = E->edge[i].link->id;
	    }
	    else{
	      eid  = E->edge[i].base->eid;
	      face = E->edge[i].base->id;
	    }

	    vb = V[eid*vertmax + UL->flist[eid]->fnum1(face,j)].base;
	    
	    if(eid < E->id){  /* connect to lower element */
	      if(!v->base) v->base = v;
	      
	      /* search through all points and assign to same base */
	      for(;vb->link;vb = vb->link);
	      if(vb->base != v->base) vb->link = v->base;
	      for(v = v->base;v; v = v->link) v->base = vb->base;
	    }
	    else if(!v->base) v->base = v;
	  }
	  else if(!v->base) v->base = v;
	}
      }
  }

  if(U->dim() == 3){
    double x, y, z, x1, y1, z1, cx, cy, cz, TOL = 1E-5;
    int vn, vn1, flag, nfv;
    Element *F;
    
    for(E = U; E; E = E->next)
      for(i = 0; i < E->Nfaces; ++i){
	for(j = 0; j < E->Nfverts(i); ++j){
	  
	  vn = E->vnum(i,j);

	  v = V+E->id*vertmax + vn;
	  
	  if(E->face[i].link){
	    eid  = E->face[i].link->eid;
	    face = E->face[i].link->id;
	    F    = UL->flist[eid];
	    
	    nfv = F->Nfverts(face);

	    x = E->vert[vn].x;
	    y = E->vert[vn].y;
	    z = E->vert[vn].z;
	    
	    cx = 0.0; cy = 0.0; cz = 0.0;
	    for(k=0;k<nfv;++k){
	      cx+=F->vert[F->vnum(face,k)].x-E->vert[E->vnum(i,k)].x;
	      cy+=F->vert[F->vnum(face,k)].y-E->vert[E->vnum(i,k)].y;
	      cz+=F->vert[F->vnum(face,k)].z-E->vert[E->vnum(i,k)].z;
	    }
	    cx /= 1.*nfv;      cy /= 1.*nfv;      cz /= 1.*nfv;

	    // loop through vertices on neighbour face
	    // break out when match is made
	    flag = 1;
	    for(k=0;k < nfv;++k){
	      vn1 = F->vnum(face,k);
	      x1  = F->vert[vn1].x-cx; 
	      y1  = F->vert[vn1].y-cy;
	      z1  = F->vert[vn1].z-cz;
	      if(sqrt((x1-x)*(x1-x)+
		      (y1-y)*(y1-y)+(z1-z)*(z1-z))<TOL){
		flag = 0;
		break;
	      }
	    }
	    
	    if(flag) 
	      fprintf(stderr, 
		      "Error in SetGid  Elmt:%d Face:%d Vertex:%d\n",
		      E->id, i, j);
	    
	    vb = V[eid*vertmax + vn1].base;
	    
	    /* connect to lower element */
	    
	    if(eid <= E->id){  
	      if(!v->base) v->base = v;
	      
	      /* search through all points and assign to same base */
	      if(vb){
		for(;vb->link;vb = vb->link);
		if(vb->base != v->base) vb->link = v->base;
		for(v = v->base;v; v = v->link) v->base = vb->base;
	      }
	    }
	    else if(!v->base) v->base = v;
	  }
	  else if(!v->base) v->base = v;
	}
      }
  }
  
  /* number vertices consequatively */
  for(E = U, nvg = 1; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      if(!V[E->id*vertmax+i].base->id) 
	V[E->id*vertmax+i].id = V[E->id*vertmax+i].base->id = nvg++;
      else                       
	V[E->id*vertmax+i].id = V[E->id*vertmax+i].base->id;
  nvg--;

  for(E = U; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i)
      E->vert[i].gid = V[E->id*vertmax+i].id-1;

  // do stuff here
  for(E = U; E; E = E->next)
    for(i = 0; i < E->Nverts; ++i){
      vb  = V[E->id*vertmax+i].base;
      if(!E->vert[i].base && vb){
	if(!UL->flist[vb->eid]->vert[vb->vid].base){
	  for(v=vb;v;v=v->link){
	    UL->flist[v->eid]->vert[v->vid].base = 
	      UL->flist[vb->eid]->vert+ vb->vid;
	    if(v->link)
	      UL->flist[v->eid]->vert[v->vid].link = 
		UL->flist[v->link->eid]->vert + v->link->vid;
	  }
	}
      }
    }

  /* set gid's to -1 */
  for(E = U; E; E = E->next){
    for(i = 0; i < E->Nedges; ++i) E->edge[i].gid = -1;
    for(i = 0; i < E->Nfaces; ++i) E->face[i].gid = -1;
  }
  
  /* at present just number edge and faces consequatively */
  faceid = 0; edgeid = 0;
  for(E = U; E; E = E->next){
    e = E->edge;
    for(i = 0; i < E->Nedges; ++i){
      if(e[i].gid==-1)
	if(e[i].base){
	  for(ed = e[i].base; ed; ed = ed->link)
	    ed->gid = edgeid;
	  ++edgeid;
	}
	else
	  e[i].gid = edgeid++;
    }
    f = E->face;
    for(i = 0; i < E->Nfaces; ++i)
      if(f[i].gid==-1)
	if(f[i].link){
	  f[i].gid       = faceid;
	  f[i].link->gid = faceid++;
	}
	else
	  f[i].gid       = faceid++;
  }
  
  free(V);
  return;
}

static int suminterior(Element *E){
  int sum=0;
  for(;E;E = E->next)
    sum += E->Nmodes - E->Nbmodes;

  return sum;
}

static void set_bmap(Element *U, Bsystem *B){
  register int i,j,k,n;
  int   l;
  const int nel = B->nel;
  int  **bmap;
  Element *E;

  /* declare memory */
  bmap = (int **) malloc(nel*sizeof(int *));
  for(E=U,l=0;E;E=E->next) l += E->Nbmodes;

  bmap[0] = ivector(0,l-1);
  for(i = 0, E=U; i < nel-1; ++i, E=E->next)
    bmap[i+1] = bmap[i] + E->Nbmodes;

  /* fill with bmaps */
  for(E=U;E;E=E->next){
    for(j = 0; j < E->Nverts; ++j)
      bmap[E->id][j] = E->vert[j].gid;
    
    n = E->Nverts;

    for(j = 0; j < E->Nedges; ++j,n+=l){
      l = E->edge[j].l;
      for(k = 0; k < l; ++k)
        bmap[E->id][n+k] = B->edge[E->edge[j].gid] + k;
    }

    if(E->dim() == 3)
      for(k = 0; k < E->Nfaces; ++k){
	l = E->face[k].l;

	if(E->Nfverts(k) == 3){ // triangle face
	  l = l*(l+1)/2;
	  for(i = 0; i < l; ++i)
	    bmap[E->id][n+i] = B->face[E->face[k].gid] + i;
	  n += l;
	}
	else{  // square face
	  if(E->face[k].con < 4){
	    for(i=0;i<l;++i)
	      for(j=0;j<l;++j)
		bmap[E->id][n+j+i*l] = B->face[E->face[k].gid]+j+i*l;
	  }
	  else{ // transpose modes
	    for(i=0;i<l;++i)
	      for(j=0;j<l;++j)
		bmap[E->id][n+i+j*l] = B->face[E->face[k].gid]+j+i*l;
	    //	    E->face[k].con -= 4;
	  }
	  n += l*l;
	}
      }
  }

  B->bmap = bmap;
}

#if 1
/* ---------------------------------------------------------------------- *
 * backup() -- Create a backup copy of a file                             *
 * ---------------------------------------------------------------------- */

int backup (char *path1)
{
  int  stat;
  char path2[FILENAME_MAX];

  sprintf (path2, "%s.bak", path1);
  unlink  (path2);                    /* unlink path2 regardless    */
  if (!(stat = link(path1, path2)))   /* try to link path1 -> path2 */
    unlink (path1);                   /* unlink path1 only if the   */
  return stat;                        /* link was sucessful         */
}
#endif
