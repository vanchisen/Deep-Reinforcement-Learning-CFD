/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/vort_old.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "vort";
char *usage  = "vort:  [options]  -r file[.rea]  input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  "-q      ... quadrature point spacing. Default is even spacing\n"
  "-R      ... range data information. must have mesh file specified\n"
  "-b     ... make body elements specified in mesh file\n"
#if DIM == 2
  "-n #    ... Number of mesh points. Default is 15\n";
#else
  "-n #    ... Number of mesh points.";
#endif

typedef struct body{
  int N;       /* number of faces    */
  int *elmt;   /* element # of face  */ 
  int *faceid; /* face if in element */
} Body;

static Body bdy;

typedef struct range{
  double x[2];
  double y[2];
  double z[2];
} Range;

static Range *rnge;

static void setup (FileList *f, Element_List **U, Field *fld);
static void Get_Body(FILE *fp);
static void dump_faces(FILE *out,Element **E, Coord X, int nel, int zone,
		       int nfields);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void Write(Element_List **E, FILE *out, int nfields);
int readHeaderF(FILE* fp, Field *f);

main (int argc, char *argv[])
{
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List **master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file is wrong dimension);

  master = (Element_List **) malloc(((nfields = strlen(fld.type))+3)
			       *sizeof(Element_List *));

  setup (&f, master, &fld);
  Write(master,f.out.fp, nfields);
  
  return 0;
}

static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i;
  int nfields = strlen(fld->type);
  int nftot   = strlen(fld->type)+3;

  ReadParams  (f->rea.fp);

  option_set("NZ", fld->nz);
  option_set("NZTOT", fld->nz);

  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }    
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     
  U[0]->fhead->type = fld->type[0];
  
  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
  }

  // #if DIM == 3
  if(f->mesh.name) Get_Body(f->mesh.fp);
  // #endif

  readFieldF(f->in.fp, fld, U[0]);
  
  for(i = 0; i < nfields; ++i)
    copyfieldF(fld,i,U[i]);
   
  freeField (fld);

  for(i = nfields; i < nftot; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = 'W';
  }

  return;
}

static int Check_range(Element *E);

static void Write(Element_List **E, FILE *out, int nfields){
  Element_List *U, *V, *W, *P;
  register int i,k,n;
  int      qa,qb,qc,qt,zone;
  double   *z,*w;
  Coord    X;

  double  *d = dvector(0, E[0]->nz*E[0]->htot-1);
  
  int nq = E[0]->nz*E[0]->htot;

  U = E[0];  V = E[1];  W = E[2]; P = E[3];

  U->Trans(U, J_to_Q);
  V->Trans(V, J_to_Q);
  W->Trans(W, J_to_Q);
  P->Trans(P, J_to_Q);

  // WX = Vz - Wy
  V->Grad_z (E[nfields]);
  W->Grad(0, E[nfields+1], 0, 'y');
  daxpy(nq, -1.0, E[nfields+1]->base_h, 1, E[nfields]->base_h, 1);
  E[nfields]->Set_state('p');
  
  // WY = Uz - Wx
  U->Grad_z(E[nfields+1]);
  W->Grad  (E[nfields+2], 0, 0, 'x');
  daxpy(nq, -1.0, E[nfields+2]->base_h, 1, E[nfields+1]->base_h, 1);  
  E[nfields+1]->Set_state('p');  

  // WZ = Uy - Vx
  V->Grad(E[nfields+2], 0, 0, 'x');
  dcopy(nq, E[nfields+2]->base_h, 1, d, 1);
  U->Grad(0, E[nfields+2], 0, 'y');
  daxpy(nq, -1.0, d, 1, E[nfields+2]->base_h, 1);
  E[nfields+2]->Set_state('p');
  if(!option("Qpts")){
    E[nfields]->Trans(E[nfields], Q_to_J);
    E[nfields+1]->Trans(E[nfields+1], Q_to_J);
    E[nfields+2]->Trans(E[nfields+2], Q_to_J);
  }
  
  nfields += 3;
  if(option("Qpts")){
    for(i = 0; i < nfields; ++i){
      E[i]->Set_state('p');
      E[i]->Trans(E[i], F_to_P);
    }
  }
  else{
    Element *F;
    for(i = 0; i < nfields; ++i){
      E[i]->Set_state('t');
      E[i]->Trans(E[i], F_to_P);
    }
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Tri){
	Basis *b = F->getbasis();
	getzw(F->qa,&z,&w,'a');
	for(i = 0; i < F->qa; ++i) z[i] = 2.0*i/(double)(F->qa-1) -1.0;
	getzw(F->qb,&z,&w,'b');
	for(i = 0; i < F->qb; ++i) z[i] = 2.0*i/(double)(F->qb-1) -1.0;
	b->id = 0;
	break;
      }
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Quad){
	Basis *b = F->getbasis();
	getzw(F->qa,&z,&w,'a');
	for(i = 0; i < F->qa; ++i) z[i] = 2.0*i/(double)(F->qa-1) -1.0;
	b->id = 0;
	break;
      }
  
    /* force to regenerate basis */
    for(F=E[0]->fhead;F;F=F->next)
      F->getbasis()->id=0;
    
    for(i = 0; i < nfields; ++i)  E[i]->Trans(E[i],J_to_Q);
  }

  qt = QGmax*QGmax;
  fprintf(out,"VARIABLES = x y z");

  X.x = dvector(0,qt-1);
  X.y = dvector(0,qt-1);

  for(i = 0; i < nfields-3; ++i)
    fprintf(out," %c", E[i]->fhead->type);
  fprintf(out," Wx Wy Wz \n");

  int j;

  if(option("FEstorage")){
    for(k = 0,i=0,n=0; k < E[0]->nel; ++k){
      i += E[0]->flist[k]->qa*E[0]->flist[k]->qb;
      n += (E[0]->flist[k]->qa-1)*(E[0]->flist[k]->qb-1);
    }
    fprintf(out,"ZONE N=%d, E=%d, F=FEPOINT, ET=QUADRILATERAL\n", i, n);
    
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < qt; ++i){
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
      }
    }
    
    for(k = 0,n=1; k < E[0]->nel; ++k){
      for(i=0;i<E[0]->flist[k]->qb-1;++i)
	for(j=0;j<E[0]->flist[k]->qa-1;++j){
	  fprintf(out,"%d %d %d %d\n",n+j+i*E[0]->flist[k]->qa,
		  n+j+1+i*E[0]->flist[k]->qa,
		  n+j+1+(i+1)*E[0]->flist[k]->qa,
		  n+j+(i+1)*E[0]->flist[k]->qa);
	}
      n+= E[0]->flist[k]->qa*E[0]->flist[k]->qb;
    }
  }
  else{
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
		++zone,E[0]->flist[k]->qa,E[0]->flist[k]->qb, E[0]->nz+1);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flevels[j]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
	for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
	  fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	  for(n = 0; n < nfields; ++n)
	    fprintf(out," %lg",E[n]->flevels[0]->flist[k]->h[0][i]);
	  fputc('\n',out);
	}
      }
    }
  }
  
  free(X.x); free(X.y);
  free(d);
}

#ifdef EXCLUDE
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
      if((E->vert[i].x < rnge->x[0])||(E->vert[i].x > rnge->x[1])) return 0;
      if((E->vert[i].y < rnge->y[0])||(E->vert[i].y > rnge->y[1])) return 0;
#if DIM == 3
      if((E->vert[i].z < rnge->z[0])||(E->vert[i].z > rnge->z[1])) return 0;
#endif
    }
  }
  return 1;
}
#else
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
#if DIM == 3
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1]) 
         && (E->vert[i].z > rnge->z[0])&&(E->vert[i].z < rnge->z[1])) return 1;
#else
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1])) return 1;
#endif
    }
    return 0;
  }
  else
    return 1;
}
#endif

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  iparam_set("Nout", UNSET);

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'b':
	option_set("Body",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'q':
	option_set("Qpts",1);
	break;
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
  
  /* open input file */

  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}
#if 0
static void Jtransfwd_Loc(Element **U, int nfields){
  int     asize,csize,lmax=0,N,info;
  register int i,j,n,nf;
  Element *E;
  static double  ijac;
#if DIM == 3
  double *invm = dvector(0,(LGmax*(LGmax+1)*(LGmax+2)/6)
			*(LGmax*(LGmax+1)*(LGmax+2)/6+1)/2-1);
#else
  double *invm = dvector(0,(LGmax*(LGmax+1)/2)*(LGmax*(LGmax+1)/2+1)/2-1);
#endif
  LocMat *mass  = Locmat_mem(LGmax);

  for(nf = 0; nf < nfields; ++nf)
    for(E=U[nf];E;E = E->next){
      if(lmax != E->lmax || E->curvX){

	if(E->curvX){
#if DIM == 2
	  double *save = dvector(0,QGmax*QGmax-1);
	  dcopy(E->qa*E->qb,*E->h,1,save,1);
#else
	  double *save = dvector(0,QGmax*QGmax*QGmax-1);
	  dcopy(E->qa*E->qb*E->qc,**E->h,1,save,1);
#endif	  
	  LocMassMatC(E,mass);
#if DIM == 2
	  dcopy(E->qa*E->qb,save,1,*E->h,1);
#else
	  dcopy(E->qa*E->qb*E->qc,save,1,**E->h,1);
#endif
	  free(save);
	}
	else
	  LocMassMat(E,mass);
	
	asize = Nvert;
	for(i = 0; i < Nedge; ++i)
	  asize += E->edge[i].l;
#if DIM == 3
	for(i = 0; i < Nface; ++i)
	  asize += E->face[i].l*(E->face[i].l+1)/2;
	
	/* calc local interior matrix size */
	csize = E->l*(E->l+1)*(E->l+2)/6;
#else
	csize = E->face->l*(E->face->l+1)/2;
#endif
	
	for(i = 0,n=0; i <asize; ++i){
	  for(j=i;j < asize; ++j,++n)
	    invm[n] = mass->a[i][j];
	
	  dcopy(csize,mass->b[i],1,invm+n,1);
	  n += csize;
	}
      
	for(i = 0; i < csize; ++i)
	  for(j = i; j < csize; ++j,++n)
	    invm[n] = mass->c[i][j];
	
	N = asize + csize;
	
	dpptrf('L',N,invm,info);
	if(info) error_msg(Jtransfwd_Loc: info not zero);
	if(E->curvX)  lmax = 0;
	else{
	  ijac = 1.0/E->geom->jac.d;
	  lmax = E->lmax;
	}
      }
    
      EIprod(E,E);
      dpptrs('L',N,1,invm,E->vert->hj,N,info);
      if(!E->curvX) 
	dsmul(N,1.0/(ijac*E->geom->jac.d),E->vert->hj,1,E->vert->hj,1);
    }  


  free(invm);
  Locmat_free(mass,LGmax);
}
#endif
static void Get_Body(FILE *fp){
  register int i;
  char buf[BUFSIZ],*s;
  int  N;

  if(option("Range")){
    rnge = (Range *)malloc(sizeof(Range));
    rewind(fp);  /* search for range data */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Range"));

    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->x,rnge->x+1);
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->y,rnge->y+1);
#if DIM == 3
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->z,rnge->z+1);
#endif
  }

  if(option("Body")){
    rewind(fp);/* search for body data  */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Body"));   
    
    if(s!=NULL){
      
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&N);
      
      bdy.N = N;
      bdy.elmt   = ivector(0,N-1);
      bdy.faceid = ivector(0,N-1);
      
      for(i = 0; i < N; ++i){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%d%d",bdy.elmt+i,bdy.faceid+i);
	--bdy.elmt[i];
	--bdy.faceid[i];
      }
    }
  }
}
#if DIM ==3
static void dump_faces(FILE *out, Element **E, Coord X, int nel, int zone, 
		       int nfields){

  int      qa = (*E)->qa, qb = (*E)->qb, qc = (*E)->qc;  
  register int i,j,k,n;
  
  for(k = 0; k < bdy.N; ++k){
    coord(E[0]+bdy.elmt[k],&X);
    
    switch(bdy.faceid[k]){
    case 0:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qb,1);
    
      for(i = 0; i < qa*qb; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], X.z[i]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i]);
	fputc('\n',out);
      }
      break;
    case 1:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qc,1);
    
      for(i = 0; i < qc; ++i){
	for(j = 0; j < qa; ++j){
	  fprintf(out,"%lg %lg %lg", X.x[qa*qb*i+j],
		X.y[qa*qb*i+j], X.z[qa*qb*i+j]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa*qb*i+j]);
	fputc('\n',out);
	}
      }
      break;
    case 2:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
    
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[qa-1 + i*qa],
		X.y[qa-1 + i*qa], X.z[qa-1 + i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa-1 + i*qa]);
	fputc('\n',out);
      }
      break;
    case 3:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
    
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i*qa],X.y[i*qa], X.z[i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i*qa]);
	fputc('\n',out);
      }
      break;
    }
  }
}
#endif
