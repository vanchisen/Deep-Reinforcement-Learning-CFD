/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/getpartial.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include "polylib.h"
#include <nektarF.h> 
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
// static char  usage_[128];

char *prog   = "getpartialF";
char *usage  = "getpartialF:  [options] -z#slices -r file[.rea] input\n";
char *author = "";
char *rcsid  = "";
char *help   = " This routine will create a 2D Fourier restart file by only saving part of the Fourier planes in the original restart. The allowed values of -z are any even number less than or equal to the original input field or 1.\n";
/* ---------------------------------------------------------------------- */

static void setup (FileList *f, Element_List **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void Write(FileList *f, Field *fld, int nfields, Element_List **V);
int readHeaderF(FILE* fp, Field *f);
int writeFieldF (FILE *fp, Field *f, Element *E);

main (int argc, char *argv[])
{
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List   **U = (Element_List**) NULL;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);
  
  U = (Element_List **) calloc((nfields = strlen(fld.type)),
			       sizeof(Element_List *));

  setup (&f, U, &fld);
  
  Write (&f, &fld, nfields, U);

  return 0;
}


static void Write(FileList *f, Field *fld, int nfields, Element_List **V)
{
  if (!option("binary"))
    fld->format    = "ascii";
  if ((fld->nz = option("NZ")) == 1)
    writeField (f->out.fp, fld, V[0]->fhead);
  else
    writeFieldF (f->out.fp, fld, V[0]->fhead);
}

static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type);
  
  ReadParams  (f->rea.fp);
  
  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }    
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     
  U[0]->fhead->type = fld->type[0];
  U[0]->Set_state('t');

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    U[i]->Set_state('t');
  }

  readFieldF(f->in.fp, fld, U[0]);

  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i, NZ = 1;
  char  fname[FILENAME_MAX];

  if (argc < 2) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    switch (c = *++argv[0]) {
    case 'z':
      if (*++argv[0]) {
	NZ = atoi (*argv);
      } else {
	NZ = atoi (*++argv);
	argc--;
      }
      // do this here for simplicity;
      option_set("NZ", NZ);
      option_set("NZTOT", NZ);
      break;
    default:
      fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
      break;
    }
  }
  
  /* open input file */
  if ((*argv)[0] == '-') {
    fprintf(stderr, "%s: standard input is not valid input!\n",prog);
    exit(-1);    
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }
  
  if (f->out.fp == stdout) {
    fprintf(stderr, "%s: standard output is not valid output!\n",prog);
    exit(-1);    
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name,  f->rea.name, f->out.name);
  }

  return;
}
