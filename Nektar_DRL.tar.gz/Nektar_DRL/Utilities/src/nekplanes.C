/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/nekplanes.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include "polylib.h"
#include <nektarF.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "extract";
char *usage  = "extract:  [options] -m new_rea[.rea]  -r file[.rea] input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = " This routine will interpolate from one mesh to another from the field file input[.fld]. It also requires the file file[.rea]\n";
/* ---------------------------------------------------------------------- */

typedef struct intepts{
  int  npts;
  Coord X;
} Intepts;

static void setup           (FileList *f, Element_List **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void Interp_point(Element_List **U, int nfields, Coord *X, double *ui);
static void Interp_pts(FILE *fp, Element_List **U, int nfields);
static void Write(FileList *f, Field *fld, int nfields, Element_List **V);
int readHeaderF(FILE* fp, Field *f);

main (int argc, char *argv[])
{
  register  int i,k;
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List   **master;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);

  master = (Element_List **) malloc((nfields = strlen(fld.type))*sizeof(Element_List *));
  setup (&f, master, &fld);

  writeFieldF(f.out.fp,&fld,master[0]->fhead);

  return 0;
}


static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type);
  Element_List *V;
  
  ReadParams  (f->rea.fp);
  
  fld->nz = option("NZTOT");
  
  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }    
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     
  
  readFieldF(f->in.fp, fld, U[0]);
  U[0]->fhead->type = fld->type[0];
  
  copyfieldF(fld,0,U[0]);
  
  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    copyfieldF(fld,i,U[i]);
  }
  
  /* New section */
  /* Generate the list of elements */
  V     = ReadMesh(f->mesh.fp, strtok(f->mesh.name,"."));
  V->fhead->type = fld->type[0];

  for(i = nfields; i < 2*nfields; ++i){
    U[i] = V->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i-nfields];
  }

  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i, NZ = 1;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'z':
	if (*++argv[0]) {
	  NZ = atoi (*argv);
	} else {
	  NZ = atoi (*++argv);
	  argc--;
	}
	// do this here for simplicity;
	option_set("NZ", NZ);
	option_set("NZTOT", NZ);
	break;
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }

  /* open input file */
  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}
