#include <stdio.h>
#include <stdlib.h>
#include <veclib.h>
#include <math.h>
#include <nektarF.h>
#include <rfftw.h>
#include <map.h>

#ifndef M_PI
#define M_PI  3.14159265358979323846
#endif

/* The following strings MUST be defined */

char *prog   = "map2tec";
char *author = "Constantinos Evangelinos";
char *rcsid  = "$Revision: 1.1 $";
char *usage  = "usage: map2tec input nzo nz radius points beta fields\n";
char *help   = "usage: map2tec input nzo nz radius points beta fields\n";

void fourier_interp (int nzo, double *uo, int nz, double *u);
void readMap (FILE *fp, Map *map);
rfftw_plan rplan_inv;

void getout()
{
  printf ("usage: map2tec input nzo nz radius points beta fields\n");
  exit   (-1);
  return;
}

main (int argc, char *argv[])
{
  char *fname;
  Map  *mapxo, *mapyo, *mapx, *mapy;
  int   nz, nzo, points, fields, i, j, k;
  double radius, theta, beta;

  if (argc != 8) getout();

  fname  = argv[1];
  nzo    = atoi (argv[2]);
  nz     = atoi (argv[3]);
  radius = atof (argv[4]);
  points = atoi (argv[5]);
  beta   = atof (argv[6]);
  fields = atoi (argv[7]);

  theta  = 2.0 * M_PI / points;

  mapxo  = allocate_map (nzo);
  mapyo  = allocate_map (nzo);
  mapx   = allocate_map (nz);
  mapy   = allocate_map (nz);
  manager_init();

  /* read the map file */

  FILE *MapFile;
  if (!(MapFile = fopen(fname,"r"))) {
    fprintf(stderr, "%s: unable to open the map file -- %s\n", 
	    prog, *argv);
    exit(1);
  }
  readMap (MapFile, mapxo);
  readMap (MapFile, mapyo);
  fclose (MapFile);

  /* fourier interpolataion  */

  mapx->NZ   = nz;
  mapy->NZ   = nz;
  mapx->time = mapxo->time;
  mapy->time = mapyo->time;

  rplan_inv = rfftw_create_plan(nz, FFTW_BACKWARD, 
				FFTW_MEASURE | FFTW_IN_PLACE, 
				COMPLEX_TO_REAL);

  fourier_interp (nzo, mapxo->d,   nz, mapx->d);
  fourier_interp (nzo, mapyo->d,   nz, mapy->d);

  /* write the map file */

  printf("ZONE T=\"Surface\", I=%d, J=%d, F=POINT\n", points + 1, nz + 1);
#ifndef SHIFTED
  for (j = 0; j < nz+1; j++) {
#else
  for (j = (nz/4); j < nz+1+(nz/4); j++) {
#endif /* ifndef SHIFTED */
    for (i = 0; i <= points; i++) {
      printf ("%#14.7g %#14.7g %#14.7g ", 
	      mapx->d[(j%nz)] + radius*cos(i*theta),
	      mapy->d[(j%nz)] + radius*sin(i*theta),
	      (2.0*M_PI*j/(nz*beta)));
      for (k = 0; k < fields; k++)
	printf("%#14.7g ", 0.0);
      putchar ('\n');
    }
  }
  return 0;
}

void fourier_interp (int nzo, double *uo, int nz, double *u)
{
  int nzero = nz - nzo;

  dcopy (min(nz, nzo), uo, 1, u, 1);

  if (nzero > 0) {
    dzero (nzero, u + nzo, 1);
    u[nzo] = u[1];
    u[1]   = 0.;
  } else
    u[1]   = 0.;

  rfftw(rplan_inv, 1, (FFTW_COMPLEX *) u, 1, 0, 0, 0, 0);
  
  return;
}

Map *allocate_map (int NZ)
{
  Map *newmap    = (Map *) calloc (1, sizeof(Map));
  
  newmap->NZ   = NZ;                                     /* number of z-plns */
  newmap->time = 0.0;                                    /* time             */

  newmap->d    = (double *) calloc (NZ, sizeof(double)); /* displacement     */
  newmap->z    = (double *) calloc (NZ, sizeof(double)); /* z   - derivative */
  newmap->zz   = (double *) calloc (NZ, sizeof(double)); /* zz  - derivative */
  newmap->t    = (double *) calloc (NZ, sizeof(double)); /* t   - derivative */
  newmap->tt   = (double *) calloc (NZ, sizeof(double)); /* tt  - derivative */
  newmap->tz   = (double *) calloc (NZ, sizeof(double)); /* tz  - derivative */
  newmap->tzz  = (double *) calloc (NZ, sizeof(double)); /* tzz - derivative */
  newmap->f    = (double *) calloc (NZ, sizeof(double)); /* forcing          */
  
  return newmap;
}

/* ------------------------------------------------------------------------ *
 * readMap() - read a single map
 * ------------------------------------------------------------------------ */

void readMap (FILE *fp, Map *map)
{
  char   buf[BUFSIZ];
  int    k, NZ, nZ;
  double time, dummy;

  /* read up to -- and then past -- next set of comment lines */
  
  while ((*buf = getc(fp)) != '#') fgets (buf, BUFSIZ, fp); ungetc (*buf, fp); 
  while ((*buf = getc(fp)) == '#') fgets (buf, BUFSIZ, fp); ungetc (*buf, fp); 
  
  fscanf (fp, "%lf", &time);
  map->time = time;

  fscanf (fp, "%d",  &NZ);
  nZ = min(NZ,map->NZ); // To avoid overwrites
  
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->d   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy); // skip over rest of line
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->z   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->zz  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->t   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tt  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tz  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tzz + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->f   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);

  return;
}
