/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/collage.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include "polylib.h"
#include <nektarF.h> 
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "collage";
char *usage  = "collage:  [options] [-D] [-R#seed] -z#slices -r file[.rea] input\n";
char *author = "";
char *rcsid  = "";
char *help   = " This routine will create a 2D Fourier restart file by assembling together #slices 2D time slices in file input_#.chk. It also requires the file file[.rea]. Specifying -D will create a restart file symmetric about an x-y plane at the half-way z-point.You need to specify an output file with the -o flag. Specifying -R#seed will randomize the sequence of the fields instead with a seed of #seed.\n";
/* ---------------------------------------------------------------------- */

static void setup (FileList *f, Element_List **U, Field *fld, int ninputs);
static int parse_util_args (int argc, char *argv[], FileList *f);
static void Write(FileList *f, Field *fld, int nfields, Element_List **V);
int readHeaderF(FILE* fp, Field *f);
void get_new(int *loc, int max, int k);
static int NZ;
static unsigned seed;

main (int argc, char *argv[])
{
  register  int i,k;
  int       dump=0,nfields,ninputs,*loc;
  Field     fld;
  FileList  f;
  Element_List   **U = (Element_List**) NULL;
  char  fname[FILENAME_MAX];

  ninputs = parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  loc = ivector(0, ninputs-1);
  if (option("random")) {
    srand(seed);
    for (k = 0; k < ninputs; k++) 
      get_new(loc, ninputs, k);
    if (option("verbose")) {
      printf ("Shuffled planes are: ");
      for (k = 0; k < ninputs; k++)
	printf(" %d", loc[k]);
      fputs("\n", stdout);
    }
  } else
    for (k = 0; k < ninputs; k++)
      loc[k] = k;

  for (k = 0; k < ninputs; k++) {
    sprintf(fname, "%s_%d.chk", f.in.name, loc[k]);
    if ((f.in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      fprintf(stderr, "%s: unable to open the input file -- %s\n",
	      prog, fname);
      exit(1);
    }
    memset(&fld, '\0', sizeof (Field));
    dump = readHeaderF (f.in.fp, &fld);
    if (!dump         ) error_msg(Restart: no dumps read from restart file);
    if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);
    
    if (!U) {
      U = (Element_List **) calloc((nfields = strlen(fld.type)),
				   sizeof(Element_List *));
      setup (&f, U, &fld, ninputs);
    }
    readField(f.in.fp, &fld, U[0]->flevels[k]->fhead);
    for(i = 0; i < nfields; ++i)
      copyfield(&fld,i,U[i]->flevels[k]->fhead);
    if (option("symmetric") && k != 0 && k != ninputs - 1) 
      for(i = 0; i < nfields; ++i)
	copyfield(&fld,i,U[i]->flevels[option("NZ")-k]->fhead);
  }

  U[0]->Set_state('t');
  U[1]->Set_state('t');
  U[2]->Set_state('t');

  U[0]->Trans(U[0], P_to_F); 
  U[1]->Trans(U[1], P_to_F); 
  U[2]->Trans(U[2], P_to_F); 
  
  Write (&f, &fld, nfields, U);

  return 0;
}


static void Write(FileList *f, Field *fld, int nfields, Element_List **V)
{
  WritefieldF (f->out.fp, f->out.name, fld->step, fld->time, nfields, V);
}

static void setup (FileList *f, Element_List **U, Field *fld, int ninputs)
{
  int i,k;
  int nfields = strlen(fld->type);
  Element_List *V;
  
  ReadParams  (f->rea.fp);
  
  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }    
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     
  U[0]->fhead->type = fld->type[0];

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    U[i]->fhead->state = U[0]->fhead->state;
  }

  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static int parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i, NZ = 1;
  char  fname[FILENAME_MAX];

  if (argc < 2) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    switch (c = *++argv[0]) {
    case 'z':
      if (*++argv[0]) {
	NZ = atoi (*argv);
      } else {
	NZ = atoi (*++argv);
	argc--;
      }
      // do this here for simplicity;
      option_set("NZ", NZ);
      option_set("NZTOT", NZ);
      break;
    case 'D':
      option_set("symmetric",1);
      // option("NZ") & option("NZTOT") should not change, only the # of inputs
      NZ = NZ/2 + 1;
      break;
    case 'R':
      option_set("random",1);
      if (*++argv[0]) {
	seed = atoi (*argv);
      } else {
	seed = atoi (*++argv);
	argc--;
      }
      break;
    default:
      fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
      break;
    }
  }
  
  /* open input file */
  if ((*argv)[0] == '-') {
    fprintf(stderr, "%s: standard input is not valid input!\n",prog);
    exit(-1);    
  } else {
    strcpy (fname, *argv);
    f->in.name = strdup(fname);
  }

  if (f->out.fp == stdout) {
    fprintf(stderr, "%s: standard output is not valid output!\n",prog);
    exit(-1);    
  }
    
  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name,  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return NZ;
}

// Recursive subroutine to add a unique random number to a list of such numbers

void get_new(int *loc, int max, int k)
{
  register int i;

  loc[k] = rand()%max;
  for (i = 0; i < k; i++)
    if (loc[k] == loc[i]) 
      get_new(loc, max, k);
}
      
