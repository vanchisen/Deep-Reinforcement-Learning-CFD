/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/extract.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektar.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "extract";
char *usage  = "extract:  [options] -m ext_file -r file[.rea] input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  " This routine will extract data described in the ext_file \n"
  " from the field file input[.fld]. It also requires the file file[.rea]\n";
/* ---------------------------------------------------------------------- */

typedef struct intepts{
  int  npts;
  Coord X;
} Intepts;

static void setup (FileList *f, Element **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);
static Intepts *Get_interp_pts(FILE *fp);
static void Interp_pts(FILE *fp, Intepts *I, Element **U, int nfields);

main (int argc, char *argv[])
{
  register  i,k;
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element   **master;
  Intepts   *I;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  while (readField (f.in.fp, &fld))dump++;
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);

  master = (Element **) malloc((nfields = strlen(fld.type))*sizeof(Element *));
  
  setup (&f, master, &fld);

  I = Get_interp_pts(f.mesh.fp);
  
  Interp_pts(f.out.fp,I,master,nfields);

  return;
}

static void Interp_pts(FILE *fp, Intepts *I, Element **U, int nfields){
  register i,j;
  double  *ui;
  Coord   X;

  ui = dvector(0,nfields-1);
  X.x = dvector(0,DIM-1);
  
  X.y = X.x+1;
#if DIM == 3
  X.z = X.y+1;
#endif

  /* print header */
#if DIM == 2
  fprintf(fp,"x y ");
#else
  fprintf(fp,"x y z ");
#endif
  for(i = 0; i < nfields; ++i)
    fprintf(fp,"%c ",U[i][0].type);
  fputc('\n',fp);

  for(i = 0; i < I->npts; ++i){
    X.x[0] = I->X.x[i]; 
    X.y[0] = I->X.y[i];
#if DIM == 2
    fprintf(fp,"%lf %lf ",X.x[0],X.y[0]);
#else
    X.z[0] = I->X.z[i];
    fprintf(fp,"%lf %lf %lf ",X.x[0],X.y[0],X.z[0]);
#endif
    Interp_point(U,nfields,&X,ui);
    for(j = 0; j < nfields; ++j)
      fprintf(fp,"%lf ",ui[j]);
    fputc('\n',fp);
  }

  free(ui);
}

static Intepts *Get_interp_pts(FILE *fp){
  int trip = 0;
  register i,j;
  char buf[BUFSIZ],*s;
  Intepts *I;
  
  I = (Intepts *)malloc(sizeof(Intepts));

  /* check for list of data points */
  rewind(fp);
  
  if(fp == stdin) trip = 1;
  if(trip) fprintf(stdout,"What type of input? (list, line, plane)\n");

  while(s=fgets(buf,BUFSIZ,fp)){
    if(strstr(s,"list")){
      if(trip) fprintf(stdout,"Number of points in list\n");

      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&I->npts);
      
      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
#if DIM == 3
      I->X.z = dvector(0,I->npts-1);
#endif
      
#if DIM == 2
      for(i = 0; i < I->npts; ++i){
	if(trip) fprintf(stdout,"Enter %d point (x,y) value\n",i+1);
	fscanf(fp,"%lf%lf",I->X.x+i,I->X.y+i);
      }
#else
      for(i = 0; i < I->npts; ++i){
	if(trip) fprintf(stdout,"Enter %d point (x,y,z) value\n",i+1);
	fscanf(fp,"%lf%lf%lf",I->X.x+i,I->X.y+i,I->X.z+i);
      }
#endif
      break;
    }
    else if(strstr(s,"line")){
      double start[DIM],stop[DIM];

      if(trip) fprintf(stdout,"Number of points in line\n");

      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&I->npts);

      /* get co-ordinates of beginning and end of line */
      if(trip) fprintf(stdout,"Enter co-ordinate of beginning of line\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",start+i);
      if(trip) fprintf(stdout,"Enter end co-ordinate of end of line\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",stop+i);

      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
#if DIM == 3
      I->X.z = dvector(0,I->npts-1);
#endif

      for(i = 0; i < I->npts; ++i){
	I->X.x[i] = i*(stop[0] - start[0])/(I->npts-1.0) + start[0];
	I->X.y[i] = i*(stop[1] - start[1])/(I->npts-1.0) + start[1];
#if DIM == 3
	I->X.z[i] = i*(stop[2] - start[2])/(I->npts-1.0) + start[2];
#endif
      }
      break;
    }
    else if(strstr(s,"plane")){
      int nx,ny;
      double X1[DIM],X2[DIM],X3[DIM],X4[DIM];

      if(trip) fprintf(stdout,"For a plane specified in anti-clockwise"
		       " direction\n");
      if(trip) fprintf(stdout,"Number of points in line from point 1 to 2\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&nx);

      if(trip) fprintf(stdout,"Number of points in line from point 1 to 4\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&ny);

      I->npts = nx*ny;

      /* get co-ordinates of plane in counter clockwise direction */
      if(trip) fprintf(stdout,"Enter co-ordinate of first point\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",X1+i);
      if(trip) fprintf(stdout,"Enter co-ordinate of second point\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",X2+i);
      if(trip) fprintf(stdout,"Enter co-ordinate of third point\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",X3+i);
      if(trip) fprintf(stdout,"Enter co-ordinate of fourth point\n");
      for(i = 0; i < DIM; ++i) fscanf(fp,"%lf",X4+i);

      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
#if DIM == 3
      I->X.z = dvector(0,I->npts-1);
#endif

      /* bilinear blend of plane */
      for(j = 0; j < ny; ++j)
	for(i = 0; i < nx; ++i){
	  I->X.x[i+j*nx]  = (i*X2[0]/(nx-1.0) + X1[0]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.x[i+j*nx] += (i*X3[0]/(nx-1.0) + X4[0]*(nx-i-1)/(nx-1.0)) *
	                                                       j/(ny-1.0);

	  I->X.y[i+j*nx]  = (i*X2[1]/(nx-1.0) + X1[1]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.y[i+j*nx] += (i*X3[1]/(nx-1.0) + X4[1]*(nx-i-1)/(nx-1.0)) *
	                                                       j/(ny-1.0);

#if DIM == 3
	  I->X.z[i+j*nx]  = (i*X2[2]/(nx-1.0) + X1[2]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.z[i+j*nx] += (i*X3[2]/(nx-1.0) + X4[2]*(nx-i-1)/(nx-1.0)) *
	                                                       j/(ny-1.0);
#endif
	}
      break;
    }
  }

  if(!s){ fprintf(stderr,"No extract  info found\n"), exit(-1);}

  return I;
}

static void setup (FileList *f, Element **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type);

  ReadParams  (f->rea.fp);

  iparam_set("LQUAD",fld->lmax+1);
  iparam_set("MQUAD",fld->lmax+1);
  
  iparam_set("MODES",fld->lmax);

  U[0] = ReadMesh(f->rea.fp);       /* Generate the list of elements */
  set_QGmax(*U); set_LGmax(*U);     /* must set for library */
  ReadSetLink     (f->rea.fp,*U);
  set_curved_elmt (*U);
  set_geofac      (*U);
  

  U[0]->type = fld->type[0];
  for(k=0; k < fld->nel; ++k){
#if DIM == 3
    mem_elmt(U[0],fld->size+11*k,'n');
#else
    mem_elmt(U[0],fld->size+4*k,'n');
#endif
  }
  copyfield(fld,0,U[0]);

  for(i = 1; i < nfields; ++i){
    U[i] = gen_aux_field(*U,'u');
    U[i]->type = fld->type[i];
    copyfield(fld,i,U[i]);
  }

  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }

  /* open input file */
  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

