/*
 * cc -o dog2tec dog2tec.c -lm
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define dvec(n) (double*)malloc(n*sizeof(double))
#define dcop(n,x,y) memcpy(y,x,n*sizeof(double))
#define PRESSURE

main (int argc, char *argv[])
{
  int     i, k, nz, count = 0, nel, dim, lgmax;
  char    *inname, outname[BUFSIZ], *tmpname = "tmp.dog2tec", buf[BUFSIZ];
  double  kinvis, lz, dz, t, t1, x, y, D, L, p, W, Wd, Wl, W0, Wl0, Wd0;
  FILE    *in, *out, *tmp;
  
  double  *x0, *y0, *D0, *L0, *p0;
  double  *x1, *y1, *D1, *L1, *p1;
  double  *x2, *y2, *D2, *L2, *p2;

  if (argc != 2) {
    printf ("usage: %s file\n", argv[0]);
    exit   (-1);
  }

  /* count how many lines in file */

  inname = argv[1];
  sprintf (outname, "%s.plt", inname);
  in     = fopen (inname, "r"); if(!in) {fprintf(stderr, "error: file %s not found\n", inname); exit(-1);}
  tmp    = stdout; // fopen (tmpname,"w");
  while   (fgets (buf, BUFSIZ, in)) count++;
  rewind  (in);
  
  /* read the header */

  fgets  (buf, BUFSIZ, in);
  fgets  (buf, BUFSIZ, in);
  fgets  (buf, BUFSIZ, in);

  fscanf (in, "%d %d %d %d", &nel, &dim, &lgmax, &nz);
  fgets  (buf, BUFSIZ, in); 

  fgets  (buf, BUFSIZ, in);
  fgets  (buf, BUFSIZ, in);
  fgets  (buf, BUFSIZ, in);

  fscanf (in, "%lf %lf", &kinvis, &lz);
  fgets (buf, BUFSIZ, in); 

  fgets  (buf, BUFSIZ, in);
  fgets  (buf, BUFSIZ, in);

  x0 = dvec (nz); x1 = dvec (nz); x2 = dvec (nz);
  y0 = dvec (nz); y1 = dvec (nz); y2 = dvec (nz);
  D0 = dvec (nz); D1 = dvec (nz); D2 = dvec (nz);
  L0 = dvec (nz); L1 = dvec (nz); L2 = dvec (nz);
  p0 = dvec (nz); p1 = dvec (nz); p2 = dvec (nz);

  dz = lz/nz;

  /* produce the tecplot file */

#ifdef PRESSURE
  fprintf (tmp, "VARIABLES = t, z, x/d, y/d, Cd, Cl, p, W, Wd, Wl\n");
  fprintf (tmp, "ZONE I=%d, J=%d, F=POINT\n", nz + 1, (count-10)/nz-2);
  for (k = 0; k < nz; k++) {
    fscanf  (in, "%lf %lf %lf %lf %lf %lf", &t, x1+k, y1+k, D1+k, L1+k, p1+k); fgets (buf, BUFSIZ, in);
  }
  for (k = 0; k < nz; k++) {
    fscanf  (in, "%lf %lf %lf %lf %lf %lf", &t, x0+k, y0+k, D0+k, L0+k, p0+k); fgets (buf, BUFSIZ, in);
  }
#else
  fprintf (tmp, "VARIABLES = t, z, x/d, y/d, Cd, Cl, W\n");
  fprintf (tmp, "ZONE I=%d, J=%d, F=POINT\n", nz + 1, (count-10)/nz-2);
  for (k = 0; k < nz; k++) {
    fscanf  (in, "%lf %lf %lf %lf %lf", &t, x1+k, y1+k, D1+k, L1+k); fgets (buf, BUFSIZ, in);
  }
  for (k = 0; k < nz; k++) {
    fscanf  (in, "%lf %lf %lf %lf %lf", &t, x0+k, y0+k, D0+k, L0+k); fgets (buf, BUFSIZ, in);
  }
#endif

  for (i = 0; i < (count-10)/nz-2; i++) {
    t1 = t;
    dcop (nz, x1, x2); dcop (nz, x0, x1);
    dcop (nz, y1, y2); dcop (nz, y0, y1);
    dcop (nz, D1, D2); dcop (nz, D0, D1);
    dcop (nz, L1, L2); dcop (nz, L0, L1);
    dcop (nz, p1, p2); dcop (nz, p0, p1);
    for (k = 0; k < nz; k++) {
#ifdef PRESSURE
      fscanf  (in, "%lf %lf %lf %lf %lf %lf", &t, x0+k, y0+k, D0+k, L0+k, p0+k); fgets (buf, BUFSIZ, in);
#else
      fscanf  (in, "%lf %lf %lf %lf %lf    ", &t, x0+k, y0+k, D0+k, L0+k      ); fgets (buf, BUFSIZ, in);
#endif
      Wd = 0.5 * D1[k]*(x0[k]-x2[k]); 
      Wl = 0.5 * L1[k]*(y0[k]-y2[k]);

      W  = Wd + Wl;
#ifdef PRESSURE
      fprintf (tmp, "%.3f %.4f %.4f %.4f %.4f %.4f %.4f %.4g %.4g %.4g\n",
	       t1, k*dz, x1[k], y1[k], 2*D1[k], 2*L1[k], p1[k], 2*W, 
	       2*Wd, 2*Wl);
#else
      fprintf (tmp, "%.3f %.4f %.4f %.4f %.4f %.4f      %.4g\n",
	       t1, k*dz, x1[k], y1[k], 2*D1[k], 2*L1[k],        2*W);
#endif
    }
    Wd0 = 0.5 * D1[0]*(x0[0]-x2[0]); 
    Wl0 = 0.5 * L1[0]*(y0[0]-y2[0]);
    
    W0  = Wd0 + Wl0;
#ifdef PRESSURE
    fprintf (tmp, "%.3f %.4f %.4f %.4f %.4f %.4f %.4f %.4g %.4g %.4g\n",
	     t1, k*dz, x1[0], y1[0], 2*D1[0], 2*L1[0], p1[0], 2*W0, 2*Wd0, 
	       2*Wl0);
#else
    fprintf (tmp, "%.3f %.4f %.4f %.4f %.4f %.4f      %.4g\n",
	     t1, k*dz, x1[0], y1[0], 2*D1[0], 2*L1[0],        2*W0);
#endif
  }

  fclose (in);
//  fclose (tmp);

  /* run preplot */

//  sprintf (buf, "preplot %s %s", tmpname, outname);
//  system  (buf);
//  remove  (tmpname);
  
  return 0;
}
