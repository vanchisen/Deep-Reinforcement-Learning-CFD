/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/mvgrid.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <hotel.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "mvgrid";
char *usage  = "mvgrid:  [options]  input[.rea]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
"-x #    ... moves x-coordinates by amount #\n"
"-y #    ... moves y-coordinates by amount #\n"
"-a #    ... rotate mesh clockwise about origin by angle # (in degrees)\n";


/* ---------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f);
static void mvgrid(FILE *in, FILE *out);

main (int argc, char *argv[])
{
  FileList   f;
  Element   *master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);
  
  mvgrid(f.rea.fp,f.out.fp);
  
  return;
}

static void mvgrid(FILE *in, FILE *out){
  register i;
  double   x[4],y[4],x1[4],y1[4];
  double   xp = dparam("Xmove"), yp = dparam("Ymove"), rot = dparam("Rot");
  char     buf[BUFSIZ];
  
  while(fgets(buf,BUFSIZ,in)){
    fputs(buf,out);
    if(strstr(buf,"ELEMENT")){
      fgets(buf,BUFSIZ,in);
      sscanf(buf,"%lf%lf%lf%lf",x,x+1,x+2,x+3);
      fgets(buf,BUFSIZ,in);
      sscanf(buf,"%lf%lf%lf%lf",y,y+1,y+2,y+3);
      for(i = 0; i < 4; ++i){
	x[i] += xp;
	y[i] += yp;
	x1[i] = x[i]*cos(rot) - y[i]*sin(rot);
	y1[i] = x[i]*sin(rot) + y[i]*cos(rot);
      }
      sprintf(buf," %lf %lf %lf %lf \n",x1[0],x1[1],x1[2],x1[3]);
      fputs(buf,out);
      sprintf(buf," %lf %lf %lf %lf \n",y1[0],y1[1],y1[2],y1[3]);
      fputs(buf,out);
    }      
  }
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  dparam_set("Xmove",NULL);
  dparam_set("Ymove",NULL);
  dparam_set("Rot"  ,NULL);

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'a':
	{ double n; 
	  if (*++argv[0]) 
	    n = atof (*argv);
	  else {
	    n = atof (*++argv);
	    argc--;
	  }
	  dparam_set("Rot",n*M_PI/180.0);
	  (*argv)[1] = '\0'; 
	}
	break;
      case 'x':
	{ double n; 
	  if (*++argv[0]) 
	    n = atof (*argv);
	  else {
	    n = atof (*++argv);
	    argc--;
	  }
	  dparam_set("Xmove",n);
	  (*argv)[1] = '\0'; 
	}
	break;
      case 'y':
	{ double n; 
	  if (*++argv[0]) 
	    n = atof (*argv);
	  else {
	    n = atof (*++argv);
	    argc--;
	  }
	  dparam_set("Ymove",n);
	  (*argv)[1] = '\0'; 
	}
	break;  
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
  

  /* open the .rea file */

  if ((*argv)[0] == '-') {
    f->rea.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.rea", *argv);
      if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->rea.name = strdup(fname);
  }
  
  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}
