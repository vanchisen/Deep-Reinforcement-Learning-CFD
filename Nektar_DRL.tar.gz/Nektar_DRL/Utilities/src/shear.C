/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/shear.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <gen_utils.h>
#include <rfftw.h>
#ifdef MAP
#include <map.h>
#endif
extern rfftw_plan rplan, rplan_inv;
extern rfftw_plan rplan32, rplan_inv32;

#define dnull ((double *) NULL)
#define Enull ((Element_List *) NULL)

/* Each of the following strings MUST be defined */

char *prog   = "shear";
char *usage  = "shear:  [options]  -r file[.rea]  input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  "-q      ... quadrature point spacing. Default is even spacing\n"
  "-R      ... range data information. must have mesh file specified\n"
  "-b      ... make body elements specified in mesh file\n"
  "-s      ... project derivatives using the mass matrix\n"
  "-z #    ... use # planes\n"
#ifdef MAP
  "-d      ... use dealiasing\n"
  "-M file ... load in the map file\n"
  "-0      ... zero-out the average displacement and derivatives\n"
#endif
  "-n #    ... Number of mesh points. Default is 15\n";


static int  setup (FileList *f, Element_List **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);

static void Write(Element_List **E, FileList f, int nfields);
Bsystem *gen_bsystem(Element_List *E, Bndry *Ebc);
int readHeaderF(FILE* fp, Field *f);

void solve(Element_List *U, Element_List *Uf, 
	   Bndry *Ubc, Bsystem *Ubsys,SolveType Stype)
{
  SetBCs (U,Ubc,Ubsys);
  Solve  (U,Uf,Ubc,Ubsys,Stype);
}

#ifdef MAP
static FILE *MapFile;
static Map *mapx, *mapy;
#endif

main (int argc, char *argv[]){
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List **master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump) error_msg(Restart: no dumps read from restart file);

  if (fld.dim != DIM) error_msg(Restart: file is wrong dimension);

  master = (Element_List **) malloc(_MAX_FIELDS*sizeof(Element_List *));
  
  nfields = setup (&f, master, &fld);

  Write(master,f, nfields);
  
  return 0;
}

/* Inner project w.r.t. orthogonal modes */

void OrthoInnerProduct(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;

  for (int k = 0; k < EL->nz; k++)
    for(U=EL->flevels[k]->fhead,Uf = ELf->flevels[k]->fhead;
	U;U = U->next,Uf = Uf->next)
      Uf->Ofwd(U->h[0], Uf->h[0], Uf->lmax);

  return;
}

void OrthoJTransBwd(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;

  for (int k = 0; k < EL->nz; k++)
    for(U=EL->flevels[k]->fhead,Uf = ELf->flevels[k]->fhead;
	U;U = U->next,Uf = Uf->next)
      Uf->Obwd(U->h[0], Uf->h[0], Uf->lmax);

  return;
}


void init_ortho_basis(void);

int setup (FileList *f, Element_List **U, Field *fld)
{
  register int i,j,k;
  //  int nfields = strlen(fld->type);
  int nfields = 4;
  //  int nftot = strlen(fld->type) + 3;
  int nftot = nfields + 4;
  double *z, *w;
  int NZ;

  ReadParams  (f->rea.fp);

  // use all the Fourier planes as a default
  if ((NZ = option("NZTOT")) < 4) {
    option_set("NZ", fld->nz);
    option_set("NZTOT", fld->nz);
    NZ = fld->nz;
  } else // otherwise use value set at command line
    option_set("NZ", NZ);

  init_rfft_struct(); // initialize RFFT structures

  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp, strtok(f->rea.name,".")); 

  init_ortho_basis();
 
  U[0]->fhead->type = fld->type[0];

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
  }

  readFieldF(f->in.fp, fld, U[0]);

  for(i = 0; i < nfields; ++i)
    copyfieldF(fld,i,U[i]);
  
  freeField (fld);

  for(i = nfields; i < nftot; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = 'W';
  }

  for(i=0;i<nfields;++i)
    U[i]->Trans(U[i],J_to_Q);

#ifdef MAP
  // allocate the maps
  mapx = allocate_map (NZ);
  mapy = allocate_map (NZ);

  // Read in the map file
  if (MapFile) {
    readMap (MapFile, mapx);
    readMap (MapFile, mapy);
    fclose  (MapFile);
  }

  // get the un-mapped values of the velocities
  mapField(U, mapx, mapy, -1);
#endif

  int ntot = U[0]->htot,
      nq = U[0]->nz*ntot;

  // WX = Wy -  Vz
  U[1]->Grad_z (U[nfields+1]);
  U[2]->Grad(Enull, U[nfields], Enull, 'y');
  daxpy(nq, -1.0, U[nfields+1]->base_h, 1, U[nfields]->base_h, 1);
  U[nfields]->Set_state('p');

  // WY = Uz - Wx
  U[0]->Grad_z(U[nfields+1]);
  U[2]->Grad  (U[nfields+2], Enull, Enull, 'x');
  daxpy(nq, -1.0, U[nfields+2]->base_h, 1, U[nfields+1]->base_h, 1);  
  U[nfields+1]->Set_state('p');  

  // WZ = Vx - Uy
  U[1]->Grad(U[nfields+2], Enull, Enull, 'x');
  U[0]->Grad(Enull, U[nfields+3], Enull, 'y');
  daxpy(nq, -1.0, U[nfields+3]->base_h, 1, U[nfields+2]->base_h, 1);
  U[nfields+2]->Set_state('p');

  // D = Ux + Vy + Wz
  U[2]->Grad_z(U[nfields+3]);

  double *d;
  if (option("dealias")) d = dvector(0, 3*nq/2-1);
  else d = dvector(0, nq-1);

  dcopy(nq, U[nfields+3]->base_h, 1, d, 1);

  U[1]->Grad  (Enull, U[nfields+3], Enull, 'y');
  daxpy(nq, 1.0, U[nfields+3]->base_h, 1, d, 1);

  U[0]->Grad  (U[nfields+3], Enull, Enull, 'x');
  daxpy(nq, 1.0, d, 1, U[nfields+3]->base_h, 1);

#ifdef MAP
  Nek_Trans_Type f_to_p = F_to_P,
                 p_to_f = P_to_F;
  rfftw_plan CPlan     = rplan, 
             CPlan_inv = rplan_inv;
  char        tripx = 'x',
              tripy = 'y';

  if (option("dealias")) {
    int nZ = NZ;
    NZ = 3*NZ/2;
    f_to_p = F_to_P32;
    p_to_f = P_to_F32;
    tripx = 'X';
    tripy = 'Y';
    CPlan     = rplan32;    
    CPlan_inv = rplan_inv32;
    // zero out for dealiasing
    dzero (NZ-nZ,   mapx->z+nZ, 1);
    dzero (NZ-nZ,   mapy->z+nZ, 1);
  }

  // Take fields to physical space
  U[0]->Trans(U[0], f_to_p);
  U[1]->Trans(U[1], f_to_p);
  U[2]->Trans(U[2], f_to_p);
  U[nfields]->Trans(U[nfields], f_to_p);
  U[nfields+1]->Trans(U[nfields+1], f_to_p);
  U[nfields+3]->Trans(U[nfields+3], f_to_p);

  // invFFT the maps to physical space
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapx->z, 1, 0, 0, 0, 0);
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapy->z, 1, 0, 0, 0, 0);

  // Correction terms for x-component of vorticity
  // Calculate Vx 
  U[1]->Grad_h (U[1]->base_h, d, dnull, dnull, tripx);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, mapx->z[k], d+k*ntot, 1, U[nfields]->base_h+k*ntot, 1);
  // Calculate Vy
  U[1]->Grad_h (U[1]->base_h, dnull, d, dnull, tripy);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, mapy->z[k], d+k*ntot, 1, U[nfields]->base_h+k*ntot, 1);

  // Correction terms for y-component of vorticity
  // Calculate Ux
  U[0]->Grad_h (U[0]->base_h, d, dnull, dnull, tripx);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, U[nfields+1]->base_h+k*ntot, 1);
  // Calculate Uy
  U[0]->Grad_h (U[0]->base_h, dnull, d, dnull, tripy);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, U[nfields+1]->base_h+k*ntot, 1);

  // Correction terms for divergence
  // Calculate Wx
  U[2]->Grad_h (U[2]->base_h, d, dnull, dnull, tripx);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, U[nfields+3]->base_h+k*ntot, 1);
  // Calculate Wy
  U[2]->Grad_h (U[2]->base_h, dnull, d, dnull, tripy);
  // add the correction term
  for (k = 0; k < NZ; k++)
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, U[nfields+3]->base_h+k*ntot, 1);

  // Bring fields back to fourier space
  U[0]->Trans(U[0], p_to_f);
  U[1]->Trans(U[1], p_to_f);
  U[2]->Trans(U[2], p_to_f);
  U[nfields]->Trans(U[nfields], p_to_f);
  U[nfields+1]->Trans(U[nfields+1], p_to_f);
  U[nfields+3]->Trans(U[nfields+3], p_to_f);  

  // FFT the maps back to fourier space
  rfftw(CPlan, 1, (FFTW_COMPLEX *)   mapx->z, 1, 0, 0, 0, 0);
  rfftw(CPlan, 1, (FFTW_COMPLEX *)   mapy->z, 1, 0, 0, 0, 0);
#endif
  
  free (d);

  if(option("SOLVE")){
    Element_List *T  = U[0]->flevels[0]->gen_aux_field('T');
    T->Cat_mem();
    Bsystem *Bsys = gen_bsystem(T, (Bndry*)NULL);
    Element_List *Tf = T->gen_aux_field('T');
    Tf->Cat_mem();
    Bsys->lambda = (Metric*) calloc(U[0]->nel, sizeof(Dorp));
    GenMat(T, NULL, Bsys, Bsys->lambda, Mass);
    
    for (k = 0; k < U[0]->nz; k++) {
      dcopy(U[nfields]->htot, U[nfields]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+1]->htot, U[nfields+1]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+1]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+2]->htot, U[nfields+2]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+2]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+3]->htot, U[nfields+3]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+3]->flevels[k], J_to_Q);
      
      //      dcopy(T->hjtot, T->base_hj, 1, U[nfields+3]->base_hj, 1);
    }
  }

  for(i=0;i<nftot;++i)
    OrthoInnerProduct(U[i],U[i]);
  
  for(i=0;i<nftot;++i)
    OrthoJTransBwd(U[i],U[i]);

  for(i = 0; i < nftot; ++i){
    U[i]->Set_state('p');
    U[i]->Trans(U[i], F_to_P);
  }

#ifdef MAP
  CPlan_inv = rplan_inv;
  // invFFT the maps to physical space
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapx->d, 1, 0, 0, 0, 0);
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapy->d, 1, 0, 0, 0, 0);
#endif

  return nftot; 
}


static void Write(Element_List **E, FileList f, int nfields)
{
  register int i,j,n;
  const int  nz  = E[0]->nz;
  int      eid;
  Coord    X;
  double   *tmp,kinvis;
  Element  *F;
  FILE     *out = f.out.fp;
  Bndry    *B,**Ubc;

  kinvis = dparam("KINVIS");

  /* take derivative of first field */

  Ubc = ReadBCs(f.rea.fp,*E);

  X.x = dvector(0,QGmax*QGmax*nz-1);
  X.y = dvector(0,QGmax*QGmax*nz-1);
  tmp = dvector(0,QGmax-1);

  fprintf(out,"VARIABLES = x y z");
  
  for(i = 0; i < nfields-4; ++i)
    fprintf(out," %c", E[i]->fhead->type);
  
  fprintf(out," shear_x shear_y shear_z Div");
  
  fputc('\n',out);

  for(B = Ubc[0]; B; B = B->next){
    if(B->type == 'W'){
      F = B->elmt;
      F->Surface_geofac(B);
      F->coord(&X);
      F->GetFace(X.x,B->face,tmp); 
      F->InterpToFace1(B->face,tmp,X.x);
      F->GetFace(X.y,B->face,tmp);
      F->InterpToFace1(B->face,tmp,X.y);
      
      eid = F->id;
      
      fprintf(out,"ZONE T=\"Element %d\", I=%d, J=%d, F=POINT\n",
	      B->elmt->id,F->qa,E[0]->nz+1);
      
      for(j = 0; j < E[0]->nz; ++j){

	for(n = 0; n < nfields-4; ++n){
	  F->GetFace(E[n]->flevels[j]->flist[eid]->h[0],B->face,tmp);
	  F->InterpToFace1(B->face,tmp,E[n]->flevels[j]->flist[eid]->h[0]);
	}
	
	for(i = 0; i < F->qa; ++i){
	  fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));

	    
	  for(n = 0; n < nfields-4; ++n)
	    fprintf(out," %lg",E[n]->flevels[j]->flist[eid]->h[0][i]);

	  if(F->curvX){
	    fprintf(out," %lg",
		    kinvis*B->ny.p[i]*E[nfields-2]->flevels[j]->flist[eid]->h[0][i]);
	    fprintf(out," %lg",
		    kinvis*B->nx.p[i]*E[nfields-2]->flevels[j]->flist[eid]->h[0][i]);
	    fprintf(out," %lg",
		    kinvis*(B->nx.p[i]*E[nfields-3]->flevels[j]->flist[eid]->h[0][i] - 
		    B->ny.p[i]*E[nfields-4]->flevels[j]->flist[eid]->h[0][i]));
	  }
	  else{
	    fprintf(out," %lg",
		    kinvis*B->ny.d*E[nfields-2]->flevels[j]->flist[eid]->h[0][i]);
	    fprintf(out," %lg",
		    kinvis*B->nx.d*E[nfields-2]->flevels[j]->flist[eid]->h[0][i]);
	    fprintf(out," %lg",
		    kinvis*(B->nx.d*E[nfields-3]->flevels[j]->flist[eid]->h[0][i] - 
		    B->ny.d*E[nfields-4]->flevels[j]->flist[eid]->h[0][i]));
	  }

	  fprintf(out," %lg",E[nfields-1]->flevels[j]->flist[eid]->h[0][i]);
	  fputc('\n',out);
	}
      }

      for(i = 0; i < F->qa; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));

	for(n = 0; n < nfields-4; ++n)
	  fprintf(out," %lg",E[n]->flevels[0]->flist[0]->h[0][i]);

	if(F->curvX){
	  fprintf(out," %lg",
		  kinvis*B->ny.p[i]*E[nfields-2]->flevels[0]->flist[eid]->h[0][i]);
	  fprintf(out," %lg",
		  kinvis*B->nx.p[i]*E[nfields-2]->flevels[0]->flist[eid]->h[0][i]);
	  fprintf(out," %lg",
		  kinvis*(B->nx.p[i]*E[nfields-3]->flevels[0]->flist[eid]->h[0][i] - 
		  B->ny.p[i]*E[nfields-4]->flevels[0]->flist[eid]->h[0][i]));
	  }
	else{
	  fprintf(out," %lg",
		  kinvis*B->ny.d*E[nfields-2]->flevels[0]->flist[eid]->h[0][i]);
	  fprintf(out," %lg",
		  kinvis*B->nx.d*E[nfields-2]->flevels[0]->flist[eid]->h[0][i]);
	  fprintf(out," %lg",
		  kinvis*(B->nx.d*E[nfields-3]->flevels[0]->flist[eid]->h[0][i] - 
		  B->ny.d*E[nfields-4]->flevels[0]->flist[eid]->h[0][i]));
	}
	
	fprintf(out," %lg",E[nfields-1]->flevels[0]->flist[eid]->h[0][i]);

	fputc('\n',out);
      }
    }
  }
  
  free(X.x); free(X.y); free(tmp);
  return;
}


/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  iparam_set("Nout", UNSET);

  while (--argc && (*++argv)[0] == '-') {
    //   while (c = *++argv[0])                  /* more to parse... */
      switch (c = *++argv[0]) {
      case 'b':
	option_set("Body",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'q':
	option_set("Qpts",1);
	break;
      case 's':
	option_set("SOLVE",1);
	break;
      case 'z':                           
	if (*++argv[0]) 
	  option_set("NZTOT", atoi(*argv));
	else {
	  option_set("NZTOT", atoi(*++argv));
	  argc--;
	}
	break;
#ifdef MAP
      case 'd':
	option_set("dealias",1);
	break;
      case 'M':                           /* read the map from a file */
	if (*++argv[0])
	  strcpy(fname, *argv);
	else {
	  strcpy(fname, *++argv);
	  argc--;
	  ++argv;
	}
	if (!(MapFile = fopen(fname,"r"))) {
	  fprintf(stderr, "%s: unable to open the map file -- %s\n", 
		  prog, *argv);
	  exit(1);
	}
	break;
      case '0':
	option_set("nomean",1);
	break;
#endif
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
  
  /* open input file */

  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

