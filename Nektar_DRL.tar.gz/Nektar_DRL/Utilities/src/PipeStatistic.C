/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source:$
 * $Revision:$
 * $Date:$ 
 * $Author:$ 
 * $State:$ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include "Quad.h"
#include "Tri.h"
#include <gen_utils.h>
#include <rfftw.h>
#ifdef MAP
#include <map.h>
#endif
/*
int find_elmt_coords_2d (Element_List *U, double xo, double yo, 
			    int *eid, double *a, double *b);
void Find_local_coords(Element_List *U, Coord *X, int Npts, int **Eids, Coord **A);
void get_point_shape_2d(Element *E, double a, double b, double *hr, double *hs);
double eval_field_at_pt_2d(int qa, int qb, double *field, double *hr, double *hs);
void Prt_find_local_coords(Element_List *U, Coord X,
                           int *Eid, Coord *A, char status);
void Interpolate_field_values(Element_List **U, int Nfields, int Npts,
								int *Eids, Coord *A, double ***data);
*/
extern rfftw_plan rplan, rplan_inv;
extern rfftw_plan rplan32, rplan_inv32;
/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "nek2tec";
char *usage  = "nek2tec:  [options]  -r file[.rea]  input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  "-q     ... quadrature point spacing. Default is even spacing\n"
  "-R     ... range data information. must have mesh file specified\n"
  "-b     ... make body elements specified in mesh file\n"
  "-z #     ... use # planes\n"
  "-g #     ... average values using # waves\n"
#ifdef MAP
  "-d       ... use dealiasing\n"
  "-M file  ... load in the map file\n"
  "-0       ... zero-out the average displacement and derivatives\n"
#endif
#ifdef EDGES`
  "-p #   ... edge expansion order\n"
  "-t #   ... fill percentage [0-1]\n"
#endif
  #if DIM == 2
  "-n #   ... Number of mesh points. Default is 15\n";
#else
  "-n #   ... Number of mesh points.";
#endif

/* ---------------------------------------------------------------------- */

typedef struct body{
  int N;       /* number of faces    */
  int *elmt;   /* element # of face  */ 
  int *faceid; /* face if in element */
} Body;

static Body bdy;

typedef struct range{
  double x[2];
  double y[2];
  double z[2];
} Range;

static Range *rnge;

static int  setup (FileList *f, Element_List **U, Field *fld);
static void Get_Body(FILE *fp);
static void dump_faces(FILE *out,Element **E, Coord X, int nel, int zone, 
		       int nfields);
static void parse_util_args (int argc, char *argv[], FileList *f);
#ifdef MAP
void mapField (Element_List **E, Mapping *mapx, Mapping *mapy, int dir);
 static void Write(Element_List **E, Mapping *mapx, Mapping *mapy, FILE *out, 
		  int nfields);
#else
static void Write(Element_List **E, FILE *out, int nfields);
 #endif
int readHeaderF(FILE* fp, Field *f);

#ifdef MAP
static FILE *MapFile;
static Mapping *mapx, *mapy;
#endif

double radius = 0.5;
static int    Nc = 32;
static int    Nr = 64;
double len_c = 2.*M_PI/(double)Nc;
double len_r = radius/(double)Nr;
static int    num_points  = Nc*Nr;
static double *local_coordsx;
static double *local_coordsy;
static double *local_coordsID;

static double *interp_r;
static int zz[4] = {0,15,31,47};

main (int argc, char *argv[])
{
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
   Element_List **master;
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);

  master = (Element_List **) malloc((nfields = strlen(fld.type))*sizeof(Element_List *));
  nfields = setup (&f, master, &fld);

#ifdef MAP
  Write(master,mapx,mapy,f.out.fp, nfields);
#else
  Write(master,f.out.fp,nfields);
#endif
  
  return NULL;
}

void FindLocalCoords(Element_List *U);

int setup (FileList *f, Element_List **U, Field *fld)
{
  register int i,j,k;
  
  int nftot = strlen(fld->type);
  int nfields = nftot;
  //  int nftot = strlen(fld->type) + 3;
  //int nftot = nfields + 4;
  double *z, *w;
  int NZ;

  ReadParams  (f->rea.fp);

  // use all the Fourier planes as a default
   if ((NZ = option("NZTOT")) < 4) {
    option_set("NZ", fld->nz);
    option_set("NZTOT", fld->nz);
    NZ = fld->nz;
  } else // otherwise use value set at command line
    option_set("NZ", NZ);

   init_rfft_struct(); // initialize RFFT structures

  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
      }
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp, strtok(f->rea.name,".")); 
  
  double gamma = 2.25;
  interp_r = dvector(0,Nr-1); 
  
  local_coordsID = dvector(0,num_points-1);
  local_coordsx = dvector(0,num_points-1);
  local_coordsy = dvector(0,num_points-1);
  
  Coord XX,*YY;
  XX.x = dvector(0,2-1); 
  XX.y = XX.x + 1;
  for(int j=0; j<Nr; ++j)
    {
        double dNr = (double) Nr;
        double dj = (double) j;
        double rr =  -radius*tanh(gamma*(dNr-dj)/(dNr-1.))/tanh(gamma);
        interp_r[j] = rr;
      for(int i=0; i<Nc; ++i)
       {
          int m = j*Nc+i;
          int *eid ;
          double theta = 0.5*len_c + i*len_c;
          
//          XX.x[0] = rr*cos(theta);
//          XX.y[0] = rr*sin(theta);
          XX.x[0] = 0.25;
          XX.y[0] = 0.48;
          
//          Find_local_coords(U[0],&XX,1,&eid,&YY);
          FindLocalCoords(U[0],&XX,1,&eid,&YY);
          
          if(eid[0] != -1)
          {
           local_coordsID[m] = eid[0];
           local_coordsx[m] = YY->x[0];
           local_coordsy[m] = YY->y[0];

           fprintf(stderr,"%d  %f  %f \n",eid[0],XX.x[0], XX.y[0]);
          }
          else
           {
             fprintf(stderr,"can't find points %g , %g \n",XX.x[0],XX.y[0]);
             exit(-1);
           }
       }
    }

  free(XX.x);
//  FindLocalCoords(U[0]);

  init_ortho_basis();
 
  if(f->mesh.name) Get_Body(f->mesh.fp);

  U[0]->fhead->type = fld->type[0];

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
  }

  
 if(1||option("oldhybrid")) // at present need this to read in old files
    set_nfacet_list(U[0]);
//  readFieldF(f->in.fp, fld, U[0]);
  readField (f->in.fp, fld);
  
  for(i = 0; i < nfields; ++i)
    copyfieldF(fld,i,U[i]);
   
  freeField (fld);

  for(i = nfields; i < nftot; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = 'W';
  }

  for(i=0;i<nfields;++i)
    U[i]->Trans(U[i],J_to_Q);

#ifdef MAP
  Nek_Trans_Type f_to_p = F_to_P,
                   p_to_f = P_to_F;
  rfftw_plan CPlan     = rplan, 
             CPlan_inv = rplan_inv;
  // allocate the maps
  mapx = allocate_map (NZ);
  mapy = allocate_map (NZ);
  
  // Read in the map file
  if (MapFile) {
    readMap (MapFile, mapx);
    readMap (MapFile, mapy);
    fclose  (MapFile);
  }
  
  // get the un-mapped values of the velocities
  mapField(U, mapx, mapy, -1);


  CPlan_inv = rplan_inv;
  // invFFT the maps to physical space
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapx->d, 1, 0, 0, 0, 0);
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapy->d, 1, 0, 0, 0, 0);
#endif

  return nftot;
}

void FindLocalCoords(Element_List *U){

  double gamma = 2.25;
  interp_r = dvector(0,Nr-1); 
  
  local_coordsID = dvector(0,num_points-1);
  local_coordsx = dvector(0,num_points-1);
  local_coordsy = dvector(0,num_points-1);
  
  Coord XX,*YY;
  XX.x = dvector(0,2-1); 
  XX.y = XX.x + 1;
  for(int j=0; j<Nr; ++j)
    {
        double dNr = (double) Nr;
        double dj = (double) j;
        double rr =  -radius*tanh(gamma*(dNr-dj)/(dNr-1.))/tanh(gamma);
        interp_r[j] = rr;
      for(int i=0; i<Nc; ++i)
       {
          int m = j*Nc+i;
          int *eid ;
          double theta = 0.5*len_c + i*len_c;
          
          XX.x[0] = rr*cos(theta);
          XX.y[0] = rr*sin(theta);
          
          Find_local_coords(U,&XX,1,&eid,&YY);
          
          if(eid[0] != -1)
          {
           local_coordsID[m] = eid[0];
           local_coordsx[m] = YY->x[0];
           local_coordsy[m] = YY->y[0];

           fprintf(stderr,"%d  %f  %f \n",eid[0],XX.x[0], XX.y[0]);
          }
          else
           {
             fprintf(stderr,"can't find points %g , %g \n",XX.x[0],XX.y[0]);
             exit(-1);
           }
       }
    }

  free(XX.x);
}

static int Check_range(Element *E);
static void dump_edgebox(FILE *out, Coord *X, Element **E, 
		   int edge, int zone, int eid, int nfields);

#ifdef MAP
static void Write(Element_List **E, Mapping *mapx, Mapping *mapy, FILE *out, 
		  int nfields){
#else
static void Write(Element_List **E, FILE *out, int nfields){
#endif
  register int i,j,k,n;
  const int    qa = (*E)->fhead->qa, qb = (*E)->fhead->qb, 
               qc = (*E)->fhead->qc;
  int      qt,zone;
   double   *z,*w;
  Coord    X;
  char     *outformat;
  Element  *F;

  if(!option("Qpts")){  /* reset quadrature points */ 
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Tri){
	  Basis *b = F->getbasis();
	 getzw(qa,&z,&w,'a');
	for(i = 0; i < qa; ++i) z[i] = 2.0*i/(double)(qa-1) -1.0;
	getzw(qb,&z,&w,'b');
	 for(i = 0; i < qb; ++i) z[i] = 2.0*i/(double)(qb-1) -1.0;
	b->id = 0;
	break;
      }
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Quad){
	Basis *b = F->getbasis();
	getzw(qa,&z,&w,'a');
	for(i = 0; i < qa; ++i) z[i] = 2.0*i/(double)(qa-1) -1.0;
	 b->id = 0;
	break;
      }
  }

  for(i = 0; i < nfields; ++i)  E[i]->Trans(E[i], J_to_Q);
  for(i = 0; i < nfields; ++i)  E[i]->Trans(E[i], F_to_P);

  X.x = dvector(0,QGmax*QGmax-1);
  X.y = dvector(0,QGmax*QGmax-1);
  qt = qa*qb;

  if(option("average"))
   {
     int num_waves = option("average");
     int nztot = option("NZTOT");
 
     if (nztot%num_waves){
       fprintf(stderr,"wrong number of waves !");
       exit(1);
      }

   int nz_wave = nztot/num_waves;

    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
 //average values for all waves
	 for(j = 0; j < nz_wave; ++j)
	    for(i = 0; i < qt; ++i){
       for(n = 0; n < nfields; ++n)
        {
         for(int nw=1; nw<num_waves; ++nw)
	          E[n]->flevels[j]->flist[k]->h[0][i] += E[n]->flevels[j+nw*nz_wave]->flist[k]->h[0][i];

          E[n]->flevels[j]->flist[k]->h[0][i] /=(double) num_waves;
        }


       }
//copy waverage values to outher waves
	    for(i = 0; i < qt; ++i)
       for(n = 0; n < nfields; ++n)
       for(int nw=1; nw<num_waves; ++nw)
	       for(j = 0; j < nz_wave; ++j)
           E[n]->flevels[nw*nz_wave+j]->flist[k]->h[0][i] = E[n]->flevels[j]->flist[k]->h[0][i];

    }
 
   }

//	 for(j = 0; j < nztot; ++j)
//    fprintf(stdout,"%d %d  %g \n",num_waves,j,E[2]->flevels[j]->flist[15]->h[0][0]);
  } //end of option

	   double *ha = dvector(0, QGmax-1);
	   double *hb = dvector(0, QGmax-1);
	   
     double **uu = dmatrix(0,4*Nr*Nc-1, 0, nfields-1);
     Element_List *U = E[0];

     for(int i=0; i<4*Nr*Nc; ++i)
        for(int j=0; j<nfields; ++j)
          uu[i][j] = 0.;
	   
     Coord YY;
     YY.x = dvector(0,1);
     YY.y = dvector(0,1);

     Element  *el;
     double *za,*wa,*zb,*wb,*zc,*wc;

     for(int j=0; j<Nr; ++j)
     {
      for(int i=0; i<Nc; ++i)
       {
           int id = j*Nc+i;
         for(int zt = 0; zt < 4; ++zt)
          {
            int m = j*Nc*4+i*4+zt;
            int et = (int) local_coordsID[id];
            YY.x[0] = local_coordsx[id];
            YY.y[0] = local_coordsy[id];

           for(int n = 0; n < nfields; ++n)
            {
		         el = E[n]->flevels[zz[zt]]->flist[et];
             get_point_shape_2d(el,YY.x[0],YY.y[0],ha,hb);
					   uu[m][n] = eval_field_at_pt_2d(el->qa,el->qb,el->h[0], ha, hb);

            }
//           free(data_tmp);

          }

        }
      }
 
     double **um = dmatrix(0,4*Nr-1, 0, 10);

     for(int i=0; i<4*Nr; ++i)
       for(int j=0; j<11; ++j)
          um[i][j] = 0.;

     for(int j=0; j<Nr; ++j)
      for(int i=0; i<Nc; ++i)
       for(int zt = 0; zt < 4; ++zt)
//         for(int n = 0; n < nfields; ++n)
           {
            int m = j*Nc*4+i*4+zt;
            double phi = j*len_c;

            double ur   = cos(phi)*uu[m][0]+sin(phi)*uu[m][1];
            double uphi = -sin(phi)*uu[m][0]+cos(phi)*uu[m][1];
            double uz   = uu[m][2];
            double pr   = uu[m][3];

            um[j*4+zt][0] += ur; 
            um[j*4+zt][1] += uphi; 
            um[j*4+zt][2] += uz; 
            um[j*4+zt][3] += pr; 

            um[j*4+zt][4] += ur*ur; 
             um[j*4+zt][5] += uphi*uphi; 
            um[j*4+zt][6] += uz*uz; 
            um[j*4+zt][7] += pr*pr; 

            um[j*4+zt][8]  += ur*uz; 
            um[j*4+zt][9]  += ur*uphi; 
            um[j*4+zt][10] += uz*uphi; 

           }
 
     for(int j=0; j<Nr; ++j)
       for(int zt = 0; zt < 4; ++zt)
         for(int n=0; n<11; ++n)
            um[j*4+zt][n] /= (double)Nc; 

     for(int j=0; j<Nr; ++j)
       for(int zt = 0; zt < 4; ++zt)
           {
            um[j*4+zt][4] -= um[j*4+zt][0]*um[j*4+zt][0]; 
            um[j*4+zt][5] -= um[j*4+zt][1]*um[j*4+zt][1]; 
            um[j*4+zt][6] -= um[j*4+zt][2]*um[j*4+zt][2]; 
            um[j*4+zt][7] -= um[j*4+zt][3]*um[j*4+zt][3]; 

            um[j*4+zt][8] -= um[j*4+zt][0]*um[j*4+zt][2]; 
            um[j*4+zt][9] -= um[j*4+zt][0]*um[j*4+zt][2]; 
            um[j*4+zt][10] -= um[j*4+zt][2]*um[j*4+zt][1]; 

           }

         FILE *filem;
	       char *bufm = (char*) calloc(BUFSIZ,sizeof(char));
	       sprintf(bufm, "mean_new.txt");
         filem = fopen(bufm,"aw");


       for(int zt = 0; zt < 4; ++zt)
         for(int i=Nr-1,j=0; i>=0; --i,j++)
           {
              int m = zt*Nr+j;
              fprintf(filem," %lf ", radius-interp_r[i]);
                 for(int n=0; n<11; ++n)
                   fprintf(filem," %lf  ", um[m][n]);

              fprintf(filem," %d \n", i);

            }

          fflush(filem);
          fclose(filem);
          free(bufm);

          free(uu);
          free(um);
//          free(ui);
          free(interp_r);
          free(ha);
          free(hb);
          free(YY.x);
          free(YY.y);
//          free(XX.y);

         
/*
  fprintf(out,"VARIABLES = x y z");

  for(i = 0; i < nfields; ++i)
    fprintf(out," %c", E[i]->fhead->type);
  fputc('\n',out);

  if(option("FEstorage")){
    for(k = 0,i=0,n=0; k < E[0]->nel; ++k){
      i += E[0]->flist[k]->qa*E[0]->flist[k]->qb;
      n += (E[0]->flist[k]->qa-1)*(E[0]->flist[k]->qb-1);
    }
    fprintf(out,"ZONE N=%d, E=%d, F=FEPOINT, ET=QUADRILATERAL\n", i, n);
    
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < qt; ++i){
#ifdef MAP
    if(option("average"))
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
    else
	    fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[j], X.y[i] + mapy->d[j], zmesh(j));
#else
	     fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	     for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
      }
    }
    
    for(k = 0,n=1; k < E[0]->nel; ++k){
      for(i=0;i<E[0]->flist[k]->qb-1;++i)
	for(j=0;j<E[0]->flist[k]->qa-1;++j){
	  fprintf(out,"%d %d %d %d\n",n+j+i*E[0]->flist[k]->qa,
		  n+j+1+i*E[0]->flist[k]->qa,
		  n+j+1+(i+1)*E[0]->flist[k]->qa,
		  n+j+(i+1)*E[0]->flist[k]->qa);
	}
      n+= E[0]->flist[k]->qa*E[0]->flist[k]->qb;
    }
  }
  else{
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
		++zone,E[0]->flist[k]->qa,E[0]->flist[k]->qb, E[0]->nz+1);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
#ifdef MAP
    if(option("average"))
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
    else
	    fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[j], X.y[i] + mapy->d[j], zmesh(j));
#else
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flevels[j]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
	for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
#ifdef MAP
    if(option("average"))
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
    else
	    fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[j], X.y[i] + mapy->d[j], zmesh(j));
#else
	     fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
 #endif
	  for(n = 0; n < nfields; ++n)
	    fprintf(out," %lg",E[n]->flevels[0]->flist[k]->h[0][i]);
	  fputc('\n',out);
	}
      }
    }
  }
  
  free(X.x); free(X.y);
*/
}

#ifdef EXCLUDE
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
      if((E->vert[i].x < rnge->x[0])||(E->vert[i].x > rnge->x[1])) return 0;
      if((E->vert[i].y < rnge->y[0])||(E->vert[i].y > rnge->y[1])) return 0;
#if DIM == 3
      if((E->vert[i].z < rnge->z[0])||(E->vert[i].z > rnge->z[1])) return 0;
#endif
    }
  }
  return 1;
}
#else
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
#if DIM == 3
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1]) 
         && (E->vert[i].z > rnge->z[0])&&(E->vert[i].z < rnge->z[1])) return 1;
#else
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1])) return 1;
#endif
    }
    return 0;
  }
  else
    return 1;
}
#endif
 
/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }
  iparam_set("Porder",0);
  dparam_set("theta",0.3);

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'b':
	option_set("Body",1);
	break;
      case 'f':
	option_set("FEstorage",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'z':                           
	if (*++argv[0]) 
	  option_set("NZTOT", atoi(*argv));
	else {
	  option_set("NZTOT", atoi(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0'; 
	break;
      case 'g':                           
	if (*++argv[0]) 
	  option_set("average", atoi(*argv));
	else {
	  option_set("average", atoi(*++argv));
	  argc--;
	}
	 (*argv)[1] = '\0'; 
	break;
#ifdef MAP
      case 'd':
	option_set("dealias",1);
	break;
      case 'M':                           /* read the map from a file */
	if (*++argv[0])
	   strcpy(fname, *argv);
	else {
	  strcpy(fname, *++argv);
	  argc--;
	  ++argv;
	}
	if (!(MapFile = fopen(fname,"r"))) {
	  fprintf(stderr, "%s: unable to open the map file -- %s\n", 
		  prog, *argv);
	  exit(1);
	}
	break;
      case '0':
	option_set("nomean",1);
	break;
#endif
      case 'q':
	option_set("Qpts",1);
	break;
      case 'p':
	if (*++argv[0]) 
	  iparam_set("Porder", atoi(*argv));
	else {
	  iparam_set("Porder", atoi(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      case 't':
	if (*++argv[0]) 
	  dparam_set("theta", atof(*argv));
	else {
	  dparam_set("theta", atof(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
#if DIM == 2
  if(iparam("NORDER-req") == UNSET) iparam_set("NORDER-req",15);
#endif  
  /* open input file */

  if ((*argv)[0] == '-') {
     f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

//#if DIM == 3
static void Get_Body(FILE *fp){
  register int i;
  char buf[BUFSIZ],*s;
  int  N;

  if(option("Range")){
    rnge = (Range *)malloc(sizeof(Range));
    rewind(fp);  /* search for range data */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Range"));

    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->x,rnge->x+1);
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->y,rnge->y+1);
#if DIM == 3
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->z,rnge->z+1);
#endif
  }

  if(option("Body")){
    rewind(fp);/* search for body data  */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Body"));   
    
     if(s!=NULL){
      
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&N);
      
      bdy.N = N;
      bdy.elmt   = ivector(0,N-1);
      bdy.faceid = ivector(0,N-1);
      
      for(i = 0; i < N; ++i){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%d%d",bdy.elmt+i,bdy.faceid+i);
	--bdy.elmt[i];
	--bdy.faceid[i];
      }
    }
  }
}

#ifdef TO_FIX
static void dump_faces(FILE *out, Element **E, Coord X, int nel, int zone, 
		       int nfields){

  int      qa = (*E)->qa, qb = (*E)->qb, qc = (*E)->qc;  
  register int i,j,k,n;
  
  for(k = 0; k < bdy.N; ++k){
    coord(E[0]+bdy.elmt[k],&X);
    
    
    switch(bdy.faceid[k]){
    case 0:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qb,1);
      for(i = 0; i < qa*qb; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], X.z[i]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i]);
	fputc('\n',out);
      }
      break;
    case 1:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qc,1);
      for(i = 0; i < qc; ++i){
	for(j = 0; j < qa; ++j){
	  fprintf(out,"%lg %lg %lg", X.x[qa*qb*i+j],
		X.y[qa*qb*i+j], X.z[qa*qb*i+j]);
	 for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa*qb*i+j]);
	fputc('\n',out);
	}
      }
      break;
    case 2:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[qa-1 + i*qa],
		X.y[qa-1 + i*qa], X.z[qa-1 + i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa-1 + i*qa]);
	fputc('\n',out);
      }
      break;
    case 3:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i*qa],X.y[i*qa], X.z[i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i*qa]);
	fputc('\n',out);
      }
      break;
    }
  }
}
#endif

#ifdef EDGES
static void dump_edgebox(FILE *out, Coord *X, Element **E, 
		  int edge, int zone, int eid, int nfields){

  register int i,j,k,l;
  const int    qa = E[0][eid].qa, qb= E[0][eid].qb,qc= E[0][eid].qc;
  int      q,p;
  double   cx[2],cy[2],cz[2],**x,**y,**z,*h;
  double   energy, theta;
  Element  *U = E[0]+eid;
  Basis    *b = getbasis(E[0]+eid);

  p     = iparam("Porder");
  theta = dparam("theta");

  x = dmatrix(0,2,0,QGmax-1);
   y = dmatrix(0,2,0,QGmax-1);
  z = dmatrix(0,2,0,QGmax-1);
  
  /* calculate the center points of the two adjacent faces of the edge */
  switch(edge){
  case 0:
    q = qa;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x,1,x[i],1);
      dcopy(q,X->y,1,y[i],1);
#if DIM == 3
      dcopy(q,X->z,1,z[i],1);
#endif
    }

#if DIM == 2
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#else    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;
    
    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;
#endif
    break;
  case 1:
    q = qb;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x + qa-1,qa,x[i],1);
      dcopy(q,X->y + qa-1,qa,y[i],1);
#if DIM == 3
      dcopy(q,X->z + qa-1,qa,z[i],1);
#endif
    }
#if DIM == 2
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#else
    cx[0] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;
    
    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
     cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;
#endif
    break;
  case 2:
    q = qb;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x,qa,x[i],1);
      dcopy(q,X->y,qa,y[i],1);
#if DIM == 3
      dcopy(q,X->z,qa,z[i],1);
#endif
    }
    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#if DIM == 3
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;
    break;
  case 3:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x,qa*qb,x[i],1);
      dcopy(q,X->y,qa*qb,y[i],1);
      dcopy(q,X->z,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;


    break;
  case 4:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x+qa-1,qa*qb,x[i],1);
       dcopy(q,X->y+qa-1,qa*qb,y[i],1);
      dcopy(q,X->z+qa-1,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;

    break;
  case 5:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x+qa*qb-1,qa*qb,x[i],1);
      dcopy(q,X->y+qa*qb-1,qa*qb,y[i],1);
      dcopy(q,X->z+qa*qb-1,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;

    break;
#endif
  }
  
  /* calculate (1-theta)*x_i + xc */
  for(i = 1; i < 3; ++i){
    dsmul(q,1.0-theta,x[i],1,x[i],1);
    dsmul(q,1.0-theta,y[i],1,y[i],1);
#if DIM == 3
    dsmul(q,1.0-theta,z[i],1,z[i],1);
#endif

    dsadd(q,theta*cx[i-1],x[i],1,x[i],1);
    dsadd(q,theta*cy[i-1],y[i],1,y[i],1);
#if DIM == 3
    dsadd(q,theta*cz[i-1],z[i],1,z[i],1);
#endif
  }    
   
#if DIM == 2
  fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, F=POINT\n", zone,2,q);
#else
  fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n", zone,2,2,q);
#endif  
  h = dvector(0,qa-1);

  for(j = 0; j < q; ++j){
    for(i = 0; i < DIM; ++i){
#if DIM == 2
      fprintf(out,"%lg %lg ", x[i][j],y[i][j]);
#else
      fprintf(out,"%lg %lg %lg ", x[i][j],y[i][j],z[i][j]);
#endif
      fprintf(out," %d ",E[0][eid].edge[edge].l+2 );

      if(p < E[0][eid].edge[edge].l)
	for(k = 0; k < nfields; ++k){
	  dzero(q,h,1);
	  for(l = p; l < E[k][eid].edge[edge].l; ++l)
	    daxpy(qa,E[k][eid].edge[edge].hj[l],b->edge[0][l].a,1,h,1);
	  fprintf(out," %lg",fabs(h[idamax(qa,h,1)]));
	}
      else 
	for(k = 0; k < nfields; ++k)
	  fprintf(out," %lg",0.0);
      fputc('\n',out);
    }
#if DIM == 3
    fprintf(out,"%lg %lg %lg ", x[2][j],y[2][j],z[2][j]);
    fprintf(out," %d ",E[0][eid].edge[edge].l+2 );
    
    if(p < E[0][eid].edge[edge].l)
	for(k = 0; k < nfields; ++k){
	  dzero(q,h,1);
	  for(l = p; l < E[k][eid].edge[edge].l; ++l)
	    daxpy(qa,E[k][eid].edge[edge].hj[l],b->edge[0][l].a,1,h,1);
	  fprintf(out," %lg",fabs(h[idamax(qa,h,1)]));
	}
    else 
	for(k = 0; k < nfields; ++k)
	  fprintf(out," %lg",0.0);
    fputc('\n',out);

/*      for(k = 0; k < nfields; ++k)
	fprintf(out," %lg\n",fabs(E[k][eid].edge[edge].hj[p]));*/
#endif
     }    
  free(h);
  free_dmatrix(x,0,0);  free_dmatrix(y,0,0);  free_dmatrix(z,0,0);
}
#endif




