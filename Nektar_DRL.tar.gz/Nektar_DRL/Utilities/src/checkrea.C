/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/checkrea.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektar.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "checkrea";
char *usage  = "checkrea:  [options]  input[.rea]\n";
char *author = "";
char *rcsid  = "";
char *help   = "";


/* ---------------------------------------------------------------------- */

static void setup (FileList *f, Element **U);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void checkrea(Element *E, FILE *out);

main (int argc, char *argv[])
{
  FileList   f;
  Element   *master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);
  setup (&f, &master);
  
  checkrea (master,f.out.fp);
  
  return;
}

static void setup (FileList *f, Element **U)
{
  ReadParams  (f->rea.fp);

  iparam_set("LQUAD",3);        /* set up minimum order */
  iparam_set("MQUAD",3);
  iparam_set("MODES",2);

  *U = ReadMesh (f->rea.fp);     /* Generate the list of elements */
  
  /* This must be set for library to work properly */
  set_QGmax(*U); set_LGmax(*U);
  return;
}

static void checkrea(Element *E, FILE *out){
  double abx,aby,abz;
  Vert *v;

  for(;E ; E = E->next){
    v = E->vert;
    
#if DIM == 2
    /*Take curl of vectors stemming from vertex b */
    if(((v[0].y-v[1].y)*(v[2].x-v[1].x)-(v[0].x-v[1].x)*(v[2].y-v[1].y))<0.0){
      fprintf(out,"Element %d is not counter-clockwise\n",E->id+1);
    }
    else{
      fprintf(out,"Element %d is counter-clockwise\n",E->id+1);
    }
#else
    abx = (v[1].y-v[0].y)*(v[2].z-v[0].z) - (v[1].z-v[0].z)*(v[2].y-v[0].y);
    aby = (v[1].z-v[0].z)*(v[2].x-v[0].x) - (v[1].x-v[0].x)*(v[2].z-v[0].z);
    abz = (v[1].x-v[0].x)*(v[2].y-v[0].y) - (v[1].y-v[0].y)*(v[2].x-v[0].x);
    if(((v[3].x-v[0].x)*abx + (v[3].y-v[0].y)*aby + (v[3].z-v[0].z)*abz)<0.0){
      fprintf(out,"Element %d is not counter-clockwise\n",E->id+1);
    }
    else{
      fprintf(out,"Element %d is counter-clockwise\n",E->id+1);
    }
#endif
  }
  fputs("Finished checking\n",out);

}

  

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
	break;  
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }

  /* open the .rea file */

  if ((*argv)[0] == '-') {
    f->rea.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.rea", *argv);
      if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->rea.name = strdup(fname);
  }
  
  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}
