#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------------*
 * This is a routine to add +xvalue to the x coordinate and +yvalue        *
 * to the y coordinate of an rea file.                                     *
 * Usage:    mvgrid +xvalue +yvalue file[.rea]                             *
 *-------------------------------------------------------------------------*/

main(int argc, char *argv[])
{
  double x[4],xp,yp,zp;
  char file[BUFSIZ],buf[BUFSIZ];
  FILE *fp,*fp_new;
  
#if DIM == 3
  if(argc != 5){
    fprintf(stdout,"Usage:    mvgrid +xvalue +yvalue +zvalue file[.rea] \n");
    exit(-1);
  }
#else
  if(argc != 4){
    fprintf(stdout,"Usage:    mvgrid +xvalue +yvalue file[.rea] \n");
    exit(-1);
  }
#endif
  
  if(!strstr(argv[argc-1],".rea"))
    sprintf(file,"%s.rea",argv[argc-1]);
  else
    sprintf(file,"%s",argv[argc-1]);
  
#if DIM == 3
  xp = atof(argv[argc-4]);
  yp = atof(argv[argc-3]);
  zp = atof(argv[argc-2]);
#else
  xp = atof(argv[argc-3]);
  yp = atof(argv[argc-2]);
#endif

  if(!(fp = fopen(file,"r"))){
    fprintf(stdout,"File %s does not exist\n",file);
    exit(-1);
  }

  fp_new = stdout;
  
  while(fgets(buf,BUFSIZ,fp)){
      fputs(buf,fp_new);
      if(strstr(buf,"ELEMENT")){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",x,x+1,x+2,x+3);
	sprintf(buf," %lf %lf %lf %lf \n",x[0]+xp,x[1]+xp,x[2]+xp,x[3]+xp);
	fputs(buf,fp_new);
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",x,x+1,x+2,x+3);
	sprintf(buf," %lf %lf %lf %lf \n",x[0]+yp,x[1]+yp,x[2]+yp,x[3]+yp);
	fputs(buf,fp_new);
#if DIM == 3
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",x,x+1,x+2,x+3);
	sprintf(buf," %lf %lf %lf %lf \n",x[0]+zp,x[1]+zp,x[2]+zp,x[3]+zp);
	fputs(buf,fp_new);
#endif
      }      
    }
  fclose(fp);
  fclose(fp_new);
 
  return 0;
}
    
