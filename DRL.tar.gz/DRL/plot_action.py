#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import scipy.io as sio
#from IPython import get_ipython


#get_ipython().run_line_magic('matplotlib', 'inline')
#get_ipython().run_line_magic('config', "InlineBackend.figure_format = 'retina'")
#
import matplotlib.pyplot as plt
plt.rcParams["font.family"] = "Times New Roman"


# In[6]:


fs = 15
start = 1 #start episode
end = 295 #end episode

#x = np.array(list(range(110,163)))
#x = np.array(list(range(0,(end-start)*ape)))

plt.figure(figsize=(5,5))
from matplotlib import rc
rc('text', usetex=True)


state_mean = []
state_std = []

action_mean = []
action_std = []

state_inst = []
action_inst = []

for i in range(start,end):
    f = np.load("save_data/data_{}.npz".format(i))
    state0 =  f["state"][0:-1,0]
    action0 =  f["action"][0:-1,0]
    state0=np.array(state0)
    action0=np.array(action0)

    mean_s=np.mean(state0[:,1]+2.0*3.66*(np.abs(state0[:,2]*action0[:,0])+np.abs(state0[:,3]*action0[:,1])))
    std_s =np.std(state0[:,1]+2.0*3.66*(np.abs(state0[:,2]*action0[:,0])+np.abs(state0[:,3]*action0[:,1])))
    
    mean_a=np.mean(action0,axis=0)
    std_a=np.std(action0,axis=0)

    state_mean.append(mean_s)
    state_std.append(std_s)
    action_mean.append(mean_a)
    action_std.append(std_a)


state_mean=np.array(state_mean)
action_mean=np.array(action_mean)
state_std=np.array(state_std)
action_std=np.array(action_std)


#state_mean=np.vstack(state_mean)
#action_mean=np.vstack(action_mean)
#x=np.vstack(x)
#x = range(zz0)
#print(np.shape(state_mean))

#print(state_mean[:,0])
x=range(len(state_mean[:,None])) 




ss = len(state_mean)
eta1 = np.ones(ss)
eta2 = np.ones(ss)
eta3 = np.ones(ss)

eta1.fill(1.9916) #A0
#eta2.fill(1.3206) #A06
#eta3.fill(0.884)  #A1
#eta2.fill(1.6245)  #A06
eta2.fill(1.7019)  #A1
#eta3.fill(1.5898)  #A09
eta3.fill(1.3285)  #A075


sio.savemat('Re500_T.mat',{'state':state_mean,'action':action_mean})
   # state_std.append(np.std(f["state"][50:-50,0,:], axis = 0))
   # action_std.append(np.std(f["action"][50:-50,0,:],axis = 0))
#state_mean = np.array(state_mean)
#state_std = np.array(state_std)
#action_mean = np.array(action_mean)
#action_std = np.array(action_std)

plt.title('$3D \quad Re=500 \quad \epsilon=5$ ')
ax = plt.subplot(2,1,1)
ax.tick_params(direction='in', right = True, top = True, labelsize = fs)
plt.plot(x, state_mean[:,None], 'blue', label = r'$\eta$')
plt.fill_between(x, state_mean + state_std, state_mean - state_std, color='blue',alpha=0.3)
#plt.plot(x/ape, eta2, 'green', label = r'$\epsilon/\epsilon^{max}=0.6$')
#plt.plot(x/ape, eta3, 'cyan', label = r'$\epsilon/\epsilon^{max}=0.4$')
#plt.plot(x/ape, eta1, 'red', label = r'$\epsilon/\epsilon^{max}=0.5$')
plt.plot(x, eta1, 'green',label = r'$\epsilon/\epsilon^{max}=0$')
plt.plot(x, eta2, 'yellow',label = r'$\epsilon/\epsilon^{max}=1.0$')
plt.plot(x, eta3, 'red',label = r'$\epsilon/\epsilon^{max}=0.75$')
plt.rc('grid', linestyle="--", color='black', alpha = 0.1)
plt.ylim(0.1,3.5)
plt.yticks([1.0, 1.5, 2.0])
#plt.axvline(x=88,linestyle="--", color='magenta')
#plt.yticks([0.636,0.703,0.836])
plt.grid(True)
#plt.legend(fontsize = fs, ncol = 2)
#plt.plot(x, state_mean[:], 'blue', label = r'$\overline{C_l}$')
#plt.fill_between(x, state_mean[:,0] + state_std[:,0], state_mean[:,0] - state_std[:,0], color='blue', alpha='0.3')
#plt.plot(x/ape, state_mean[:,1], 'red', label = r'$\overline{C_d}$')
#plt.fill_between(x, state_mean[:,1] + state_std[:,1], state_mean[:,1] - state_std[:,1], color='red', alpha='0.3')
#xlist = np.array([5, 10, 20])
#plt.plot(xlist, state_mean[xlist-1,1],'kx', ms = 10, markeredgewidth = 2)

#plt.plot(x, x * 0 + 0.4, 'k--', label = '$\overline{C_d^*}$')

ax = plt.subplot(2,1,2)
ax.tick_params(direction='in', right = True, top = True, labelsize = fs)
plt.plot(x,action_mean[:,0], 'black', label = r'$\epsilon_1/\epsilon^{max}$')
plt.fill_between(x, action_mean[:,0] + action_std[:,0], action_mean[:,0] - action_std[:,0], color='black', alpha=0.3)
plt.plot(x, action_mean[:,1], 'magenta', label = r'$\epsilon_2/\epsilon^{max}$')
plt.fill_between(x, action_mean[:,1] + action_std[:,1], action_mean[:,1] - action_std[:,1], color='magenta', alpha=0.3)

plt.ylim(-1.1,1.1)
plt.yticks([-1.0, -0.5, 0, 0.5,1.0])
#plt.xlim(110,148)
plt.xlabel('episode', fontname="Times New Roman", fontsize = fs)
# plt.ylabel(r'$\epsilon/\epsilon^{max}$', fontsize = fs)
plt.rc('grid', linestyle="--", color='black', alpha = 0.1)
plt.grid(True)
#plt.legend(fontsize = fs, ncol = 2)
plt.savefig('Re500_Task2.png',format='png',dpi = 600, bbox_inches='tight', pad_inches=0)


# Create Map
#cm = plt.get_cmap("RdYlGn")
#scatter_size = end-start
#col = [cm(float(i)/(scatter_size)) for i in xrange(scatter_size)]
'''
fig = plt.figure()
ax = fig.add_subplot(111)

ax.scatter(action_mean, state_inst, c=state_inst, marker='o')

plt.ylim(0.2,1.5)
ax.set_xlabel(r'$\epsilon_1$')
ax.set_ylabel(r'$\eta$')
plt.rc('grid', linestyle="solid", color='black', alpha = 0.1)
plt.grid(True)
plt.legend(fontsize = fs, ncol = 2)
plt.savefig('Re500_Task2_2D.png',format='png',dpi = 600, bbox_inches='tight', pad_inches=0)
'''

