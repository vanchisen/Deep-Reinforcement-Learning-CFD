import tensorflow as tf
import numpy as np
import random
import os
from utils import ReplayBuffer

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"  
os.environ["CUDA_VISIBLE_DEVICES"]= str(1)

LOG_STD_MAX = 2
LOG_STD_MIN = -8
EPS = 1e-6


def gaussian_log_den(x, mean, log_std):
    pre_sum = - 0.5 * (((x-mean)/(tf.exp(log_std)+EPS))**2 + 2 * log_std + np.log(2*np.pi))
    return tf.reduce_sum(pre_sum, axis=1, keepdims = True)

def squash(mean, action, log_den):
    new_mean = tf.tanh(mean) # actually mean is not tanh(mean)
    new_action = tf.tanh(action)
    new_log_den = log_den - tf.reduce_sum(tf.log(tf.clip_by_value(1 - new_action**2, EPS, 1.0)), axis = 1, keepdims=True)
    return  new_mean, new_action, new_log_den


class Agent:
    def __init__(self, state_size, action_size, *args, **kwargs):
        self.lr = 1e-4
        self.gamma = 0.99
        self.tau = 0.005
        self.bs = 256
        self.bfs = 1000000
        self.state_size = state_size
        self.action_size = action_size
        self.target_entropy = 0.1
        self.actor_nn_dim = [256,256, self.action_size]
        self.critic_nn_dim = [256,256, 1]

        self.this_state_place = tf.placeholder(tf.float32, [None, self.state_size])
        self.this_action_place = tf.placeholder(tf.float32, [None, self.action_size])
        self.this_reward_place = tf.placeholder(tf.float32, [None,1])
        self.this_done_place = tf.placeholder(tf.float32, [None,1])
        self.next_state_place = tf.placeholder(tf.float32, [None, self.state_size])

        self.log_alpha = tf.get_variable("log_alpha", dtype=tf.float32, initializer= 0.0)
        self.alpha = tf.exp(self.log_alpha)


        with tf.variable_scope("actor", reuse = tf.AUTO_REUSE):
            _, self.Q_next_action, self.Q_next_log_den = self.actor_nn(self.next_state_place)
        with tf.variable_scope("target_critic_1", reuse = tf.AUTO_REUSE):
            self.Q_critic_1 = self.critic_nn(self.next_state_place, self.Q_next_action)
        with tf.variable_scope("target_critic_2", reuse = tf.AUTO_REUSE):
            self.Q_critic_2 = self.critic_nn(self.next_state_place, self.Q_next_action)
        self.Q_critic_min = tf.minimum(self.Q_critic_1, self.Q_critic_2)
        self.Q_y = self.this_reward_place + self.gamma * (1-self.this_done_place) * (self.Q_critic_min - self.alpha * self.Q_next_log_den)
        # self.Q_y = self.this_reward_place + self.gamma * (self.Q_critic_min - self.alpha * self.Q_next_log_den)
        with tf.variable_scope("main_critic_1", reuse = tf.AUTO_REUSE):
            self.Q_Q_1 = self.critic_nn(self.this_state_place, self.this_action_place)
            self.Q_loss_1 = 0.5 * tf.reduce_mean((self.Q_Q_1 - self.Q_y)**2)
        with tf.variable_scope("main_critic_2", reuse = tf.AUTO_REUSE):
            self.Q_Q_2 = self.critic_nn(self.this_state_place, self.this_action_place)
            self.Q_loss_2 = 0.5 * tf.reduce_mean((self.Q_Q_2 - self.Q_y)**2)
        self.Q_loss = self.Q_loss_1 + self.Q_loss_2

        with tf.variable_scope("actor", reuse = tf.AUTO_REUSE):
            self.P_this_mean, self.P_this_action, self.P_this_log_den = self.actor_nn(self.this_state_place)
        with tf.variable_scope("main_critic_1", reuse = tf.AUTO_REUSE):
            self.P_Q_1 = self.critic_nn(self.this_state_place, self.P_this_action)
        with tf.variable_scope("main_critic_2", reuse = tf.AUTO_REUSE):
            self.P_Q_2 = self.critic_nn(self.this_state_place, self.P_this_action)
        self.P_critic_min = tf.minimum(self.P_Q_1, self.P_Q_2)
        self.P_loss = tf.reduce_mean(self.alpha * self.P_this_log_den - self.P_critic_min)


        self.alpha_loss = - tf.reduce_mean( self.log_alpha * tf.stop_gradient(self.P_this_log_den + self.target_entropy))

        all_variables = tf.trainable_variables()
        self.main_critic_var = [i for i in all_variables if "main_critic" in i.name]
        self.target_critic_var = [i for i in all_variables if "target_critic" in i.name]
        self.actor_var = [i for i in all_variables if "actor" in i.name]

        self.Q_op =  tf.train.AdamOptimizer(self.lr).minimize(self.Q_loss, var_list = self.main_critic_var) 
        self.P_op =  tf.train.AdamOptimizer(self.lr).minimize(self.P_loss, var_list = self.actor_var) 
        self.alpha_op = tf.train.AdamOptimizer(self.lr).minimize(self.alpha_loss, var_list=[self.log_alpha])        
        self.T_init = [tf.assign(T, M) for (T,M) in zip(self.target_critic_var, self.main_critic_var)]
        self.T_op = [tf.assign(T, self.tau * M + (1 - self.tau) * T) for (T,M) in zip(self.target_critic_var, self.main_critic_var)]

        self.replay_buffer = ReplayBuffer(self.state_size, self.action_size, self.bfs)

        self.step_count = 0
        self.episode_count = 0

        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        self.sess = tf.Session(config=config)
        self.sess.run(tf.global_variables_initializer())
        self.sess.run(self.T_init)
        self.saver = tf.train.Saver(max_to_keep=1000)
        


    def actor_nn(self, state, bound = True):
        dim = self.actor_nn_dim
        A = state
        for i in range(0,len(dim)-1):
            A = tf.layers.dense(A, units= dim[i], activation = tf.nn.tanh)
        mean = tf.layers.dense(A, units= dim[-1], activation = tf.nn.tanh)
        log_std = LOG_STD_MIN +  (LOG_STD_MAX - LOG_STD_MIN) * tf.layers.dense(A, units= dim[-1], activation = tf.sigmoid)
        action = mean + tf.random_normal(tf.shape(mean)) * tf.exp(log_std)
        log_den = gaussian_log_den(action, mean, log_std)
        if bound:
            mean, action, log_den = squash(mean, action, log_den)
        return mean, action, log_den


    def critic_nn(self, state, action):
        dim = self.critic_nn_dim
        A = tf.concat([state, action], axis = 1)
        for i in range(0,len(dim)-1):
            A = tf.layers.dense(A, units= dim[i], activation = tf.nn.tanh)
        critic = tf.layers.dense(A, units= dim[-1], activation = tf.nn.tanh)
        return critic



    def get_action(self, state_data, stochastic = True):
        if stochastic:
            this_action = self.sess.run(self.P_this_action, feed_dict= {self.this_state_place: state_data})
        else:
            this_action = self.sess.run(self.P_this_mean, feed_dict= {self.this_state_place: state_data})
        return this_action

    
    def train_iter(self):
        this_bs = np.minimum(self.bs, self.replay_buffer.size)
        this_batch = self.replay_buffer.sample_batch(this_bs)
        self.sess.run([self.Q_op, self.P_op, self.alpha_op], feed_dict={
                                                self.this_state_place: this_batch["obs1"],
                                                self.this_action_place: this_batch["acts"],
                                                self.this_reward_place: this_batch["rews"],
                                                self.this_done_place: this_batch["done"],
                                                self.next_state_place: this_batch["obs2"]})

        
        self.sess.run(self.T_op)


    def record(self, this_state, this_action, this_reward, this_done, next_state):
        self.replay_buffer.store(obs=this_state, 
                                act=this_action,
                                rew=this_reward,
                                next_obs=next_state,
                                done=this_done)
        self.step_count += 1


    def reset_agent(self):

        self.replay_buffer = ReplayBuffer(self.state_size, self.action_size, self.bfs)

        self.step_count = 0
        self.episode_count = 0

        self.sess.run(tf.global_variables_initializer())
        self.sess.run(self.T_init)

    def reset_episode(self):

        self.step_count = 0
        self.episode_count += 1

